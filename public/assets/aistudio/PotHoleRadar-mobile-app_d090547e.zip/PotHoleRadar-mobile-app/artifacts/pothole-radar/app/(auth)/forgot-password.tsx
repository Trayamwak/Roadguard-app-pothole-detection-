import React, { useState } from 'react';
import { StyleSheet } from 'react-native';
import { router } from 'expo-router';
import { sendPasswordResetEmail } from 'firebase/auth';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { AppButton, AppText, Field, Panel, SmallIconButton } from '@/components/AppUI';
import { auth, firebaseConfigured } from '@/lib/firebase';
import { useColors } from '@/hooks/useColors';

export default function ForgotPasswordScreen() {
  const colors = useColors();
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const sendReset = async () => {
    setMessage('');
    if (!firebaseConfigured || !auth) {
      setMessage('Connect Firebase first, then password reset emails can be sent.');
      return;
    }
    if (!email.trim()) {
      setMessage('Enter the email address on your account.');
      return;
    }
    setBusy(true);
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setMessage('If an account uses this email, a reset link is on its way.');
    } catch (cause) {
      setMessage(cause instanceof Error ? cause.message : 'Could not send the reset email.');
    } finally {
      setBusy(false);
    }
  };
  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={styles.content}
      bottomOffset={60}
      keyboardShouldPersistTaps="handled"
    >
      <SmallIconButton icon="arrow-back" accessibilityLabel="Back" onPress={() => router.back()} />
      <AppText size={30} weight="bold">Reset password</AppText>
      <AppText size={14} tone="muted">We’ll send a password reset link to your email.</AppText>
      <Panel style={styles.panel}>
        <Field label="Email address" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" />
        {message ? <AppText size={12} tone="muted" style={styles.message}>{message}</AppText> : null}
        <AppButton title="Send reset link" icon="mail-outline" loading={busy} onPress={sendReset} />
      </Panel>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 22, paddingTop: 20, gap: 18, maxWidth: 520, width: '100%', alignSelf: 'center' },
  panel: { marginTop: 5, gap: 16 },
  message: { lineHeight: 18 },
});
