import React, { useEffect, useRef, useState } from 'react';
import {
  Platform,
  Pressable,
  Share,
  StyleSheet,
  View,
} from 'react-native';
import { router } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as Haptics from 'expo-haptics';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { AppButton, AppScreen, AppText, Field, Panel, PageTitle, Pill, SeverityBadge, SmallIconButton } from '@/components/AppUI';
import { DetectionOverlay, DetectionPreview } from '@/components/DetectionOverlay';
import { compressDetectionImage, detectPotholes } from '@/lib/ai-detection';
import { blurSensitivePhoto } from '@/lib/severity';
import { useApp } from '@/providers/AppProvider';
import { useColors } from '@/hooks/useColors';
import { saveScanRecord, updateScanRecord } from '@/lib/storage';
import type { DetectionResult, PotholeReport, ScanRecord } from '@/types';

type ScanMode = 'live' | 'upload';
type Geo = { lat: number; lng: number; address: string };
const emptyDetection: DetectionResult = { potholes: [], overall_severity: 'None' };

export default function AiScanScreen() {
  const colors = useColors();
  const { user, settings, addReport } = useApp();
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const cameraRef = useRef<CameraView | null>(null);
  const inFlight = useRef(false);
  const framesScanned = useRef(0);
  const [mode, setMode] = useState<ScanMode>('live');
  const [scanSource, setScanSource] = useState<'ai_live' | 'ai_upload'>('ai_live');
  const [cameraOpen, setCameraOpen] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [frameDetections, setFrameDetections] = useState<DetectionResult>(emptyDetection);
  const [frameCount, setFrameCount] = useState(0);
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [geo, setGeo] = useState<Geo | null>(null);
  const [locationError, setLocationError] = useState('');
  const [privacyReady, setPrivacyReady] = useState(false);
  const [privacyReviewed, setPrivacyReviewed] = useState(false);
  const [note, setNote] = useState('');
  const [scanRecordId, setScanRecordId] = useState<string | null>(null);
  const [savedReportId, setSavedReportId] = useState<string | null>(null);
  const [saveMessage, setSaveMessage] = useState('');
  const [scanBusy, setScanBusy] = useState(false);
  const [saveBusy, setSaveBusy] = useState(false);
  const [scanError, setScanError] = useState('');
  const [noPothole, setNoPothole] = useState(false);

  useEffect(() => {
    if (Platform.OS === 'web') return;
    let active = true;
    Location.getForegroundPermissionsAsync()
      .then(async (permission) => {
        if (!permission.granted) return;
        const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        if (!active) return;
        const places = await Location.reverseGeocodeAsync({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        }).catch(() => []);
        if (!active) return;
        const place = places[0];
        const address = [place?.name, place?.street, place?.district || place?.city, place?.region]
          .filter((part, index, list) => !!part && list.indexOf(part) === index)
          .join(', ');
        setGeo({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          address: address || `${position.coords.latitude.toFixed(5)}, ${position.coords.longitude.toFixed(5)}`,
        });
      })
      .catch(() => undefined);
    return () => { active = false; };
  }, []);

  const clearResult = () => {
    setResult(null);
    setPhotoUri(null);
    setScanRecordId(null);
    setSavedReportId(null);
    setSaveMessage('');
    setNote('');
    setPrivacyReady(false);
    setPrivacyReviewed(false);
    setNoPothole(false);
    setScanError('');
  };

  const getLocation = async (askPermission: boolean): Promise<Geo | null> => {
    setLocationError('');
    try {
      if (Platform.OS === 'web') {
        if (!askPermission || !navigator.geolocation) return null;
        return await new Promise<Geo>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(
            (position) => resolve({
              lat: position.coords.latitude,
              lng: position.coords.longitude,
              address: `${position.coords.latitude.toFixed(5)}, ${position.coords.longitude.toFixed(5)}`,
            }),
            (error) => reject(new Error(error.message || 'Location permission was not granted.')),
            { enableHighAccuracy: true, timeout: 10000 },
          );
        });
      }
      let permission = await Location.getForegroundPermissionsAsync();
      if (!permission.granted && askPermission) permission = await Location.requestForegroundPermissionsAsync();
      if (!permission.granted) return null;
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      const places = await Location.reverseGeocodeAsync({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      }).catch(() => []);
      const place = places[0];
      const address = [place?.name, place?.street, place?.district || place?.city, place?.region]
        .filter((part, index, list) => !!part && list.indexOf(part) === index)
        .join(', ');
      return {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        address: address || `${position.coords.latitude.toFixed(5)}, ${position.coords.longitude.toFixed(5)}`,
      };
    } catch (error) {
      setLocationError(error instanceof Error ? error.message : 'Could not read or reverse-geocode your location.');
      return null;
    }
  };

  const attachLocation = async () => {
    const next = await getLocation(true);
    if (!next) {
      setLocationError((current) => current || 'Allow location access to save a report with its address.');
      return;
    }
    setGeo(next);
  };

  const makeRecord = (
    source: 'ai_live' | 'ai_upload',
    detection: DetectionResult,
    uri: string | null,
    position: Geo | null,
  ): ScanRecord => ({
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    source,
    createdAt: Date.now(),
    photoUri: uri,
    potholes: detection.potholes,
    overallSeverity: detection.overall_severity,
    address: position?.address ?? null,
    lat: position?.lat ?? null,
    lng: position?.lng ?? null,
    reportId: null,
    status: 'pending',
    note: '',
  });

  const persistReport = async (
    record: ScanRecord,
    uri: string,
    position: Geo,
    detection: DetectionResult,
    reportNote: string,
  ) => {
    if (saveBusy || detection.potholes.length === 0) return;
    setSaveBusy(true);
    setScanError('');
    const mostSevere = detection.potholes.reduce((best, current) => {
      const level = { Low: 1, Medium: 2, High: 3, Critical: 4 };
      return level[current.severity] > level[best.severity] ? current : best;
    });
    const report: PotholeReport = {
      id: record.id,
      userId: user?.uid ?? 'guest',
      authorLabel: settings.anonymousReports || !user
        ? 'Anonymous contributor'
        : user.displayName || user.email?.split('@')[0] || 'Community reporter',
      lat: position.lat,
      lng: position.lng,
      address: position.address,
      severity: detection.overall_severity === 'None' ? mostSevere.severity : detection.overall_severity,
      confidence: mostSevere.confidence,
      reason: `AI detected ${detection.potholes.length} pothole${detection.potholes.length === 1 ? '' : 's'} in the image. Severity uses box area, model confidence, and a weak perspective cue.`,
      imageUrl: null,
      source: record.source,
      status: 'open',
      upvotes: 0,
      createdAt: record.createdAt,
      note: reportNote.trim().slice(0, 500),
      localImageUri: uri,
    };
    try {
      const saved = await addReport(report);
      await updateScanRecord(record.id, {
        status: 'saved',
        reportId: saved.reportId,
        note: reportNote.trim(),
        lat: position.lat,
        lng: position.lng,
        address: position.address,
        photoUri: uri,
      });
      setSavedReportId(saved.reportId);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
      setSaveMessage(
        saved.synced
          ? saved.merged
            ? 'Nearby report found; your confirmation was added.'
            : 'Report added to the community map.'
          : 'Saved on this phone; it will sync when the connection returns.',
      );
    } catch (error) {
      setScanError(error instanceof Error ? error.message : 'Could not save this report.');
    } finally {
      setSaveBusy(false);
    }
  };

  const handleDetection = async (
    compressedUri: string,
    detection: DetectionResult,
    source: 'ai_live' | 'ai_upload',
  ) => {
    setScanSource(source);
    setResult(detection);
    setNoPothole(detection.potholes.length === 0);
    setPhotoUri(compressedUri);
    setPrivacyReviewed(false);
    setScanError('');
    if (detection.potholes.length === 0) {
      const position = geo ?? await getLocation(false);
      const record = makeRecord(source, detection, compressedUri, position);
      setScanRecordId(record.id);
      await saveScanRecord(record);
      return;
    }

    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
    let reportUri = compressedUri;
    let hasBlurred = false;
    try {
      const blurredUri = await blurSensitivePhoto(compressedUri);
      if (blurredUri) {
        reportUri = blurredUri;
        hasBlurred = true;
        setPhotoUri(blurredUri);
      }
    } catch {
      setPrivacyReady(false);
    }
    setPrivacyReady(hasBlurred);
    const position = geo ?? await getLocation(false);
    const record = makeRecord(source, detection, reportUri, position);
    setScanRecordId(record.id);
    await saveScanRecord(record);
    if (settings.autoSaveScans && position && hasBlurred) {
      await persistReport(record, reportUri, position, detection, note);
    }
  };

  const beginLiveScan = async () => {
    if (Platform.OS === 'web') {
      setScanError('Live camera scanning is available in the Android and iOS app. Use Upload Image in this preview.');
      return;
    }
    if (!cameraPermission?.granted) {
      const permission = await requestCameraPermission();
      if (!permission.granted) {
        setScanError(permission.canAskAgain ? 'Camera access was not granted. Allow it to use Live Camera.' : 'Enable camera access in your device settings.');
        return;
      }
    }
    clearResult();
    framesScanned.current = 0;
    setFrameCount(0);
    setFrameDetections(emptyDetection);
    setCameraOpen(true);
    setIsScanning(true);
  };

  const finishEmptyScan = async () => {
    const record = makeRecord('ai_live', emptyDetection, null, geo);
    setScanRecordId(record.id);
    await saveScanRecord(record);
    setResult(emptyDetection);
    setNoPothole(true);
    setCameraOpen(false);
    setIsScanning(false);
  };

  useEffect(() => {
    if (!isScanning || !cameraReady) return;
    const interval = setInterval(() => {
      if (inFlight.current || !cameraRef.current) return;
      inFlight.current = true;
      void (async () => {
        try {
          const captured = await cameraRef.current?.takePictureAsync({ quality: 0.48, exif: false });
          if (!captured?.uri) return;
          const compressedUri = await compressDetectionImage(captured.uri);
          const detection = await detectPotholes(compressedUri);
          framesScanned.current += 1;
          setFrameCount(framesScanned.current);
          setFrameDetections(detection);
          if (detection.potholes.length > 0) {
            setIsScanning(false);
            setCameraOpen(false);
        await handleDetection(compressedUri, detection, 'ai_live');
          } else if (framesScanned.current >= 10) {
            setIsScanning(false);
            await finishEmptyScan();
          }
        } catch (error) {
          setScanError(error instanceof Error ? error.message : 'Live detection failed.');
          setIsScanning(false);
          setCameraOpen(false);
        } finally {
          inFlight.current = false;
        }
      })();
    }, 1100);
    return () => clearInterval(interval);
  }, [cameraReady, isScanning]);

  const chooseImage = async () => {
    setMode('upload');
    setScanError('');
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      setScanError(permission.canAskAgain ? 'Photo library access was not granted.' : 'Enable photo access in your device settings.');
      return;
    }
    const picked = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 0.72,
    });
    if (picked.canceled || !picked.assets[0]?.uri) return;
    clearResult();
    setScanBusy(true);
    try {
      const compressedUri = await compressDetectionImage(picked.assets[0].uri);
      setPhotoUri(compressedUri);
      const detection = await detectPotholes(compressedUri);
      await handleDetection(compressedUri, detection, 'ai_upload');
    } catch (error) {
      setScanError(error instanceof Error ? error.message : 'Image scanning failed. Try another photo.');
      setResult(null);
    } finally {
      setScanBusy(false);
    }
  };

  const saveReport = async () => {
    if (!result || !photoUri || !scanRecordId || result.potholes.length === 0) return;
    if (!geo) {
      setScanError('Attach your location before saving this report.');
      return;
    }
    if (!privacyReviewed) {
      setScanError('Review the image and confirm it is safe to share.');
      return;
    }
      const record = makeRecord(scanSource, result, photoUri, geo);
    const storedRecord = { ...record, id: scanRecordId };
    await persistReport(storedRecord, photoUri, geo, result, note);
  };

  const discardResult = async () => {
    if (scanRecordId) await updateScanRecord(scanRecordId, { status: 'discarded', note: note.trim() });
    clearResult();
  };

  const retry = () => {
    clearResult();
    if (mode === 'live') void beginLiveScan();
  };

  return (
    <AppScreen scroll contentStyle={styles.content}>
      <View style={styles.header}>
        <SmallIconButton icon="chevron-back" accessibilityLabel="Go back" onPress={() => router.back()} />
        <View style={styles.headerTitle}>
          <PageTitle eyebrow="AI road check" title="Pothole scan" subtitle="Live camera or a photo from your gallery." />
        </View>
        <Pressable accessibilityRole="button" accessibilityLabel="Open scan history" onPress={() => router.push('/scan-history')} style={styles.historyIcon}>
          <Ionicons name="time-outline" size={20} color={colors.accent} />
        </Pressable>
      </View>

      <View style={styles.modeRow}>
        <Pill title="Live Camera" selected={mode === 'live'} onPress={() => { setIsScanning(false); setCameraOpen(false); setMode('live'); setScanError(''); }} />
        <Pill title="Upload Image" selected={mode === 'upload'} onPress={() => { setIsScanning(false); setCameraOpen(false); setMode('upload'); setScanError(''); }} />
      </View>

      {geo ? (
        <Panel style={styles.locationCard}>
          <Ionicons name="location" size={17} color={colors.success} />
          <View style={styles.locationCopy}>
            <AppText size={11} weight="semibold" numberOfLines={1}>{geo.address}</AppText>
            <AppText size={10} tone="muted">GPS attached · used only if you save the report</AppText>
          </View>
          <Pressable accessibilityRole="button" onPress={attachLocation} style={styles.refreshLocation}>
            <Ionicons name="refresh-outline" size={17} color={colors.accent} />
          </Pressable>
        </Panel>
      ) : (
        <Panel style={styles.locationCard}>
          <Ionicons name="location-outline" size={18} color={colors.accent} />
          <View style={styles.locationCopy}>
            <AppText size={11} weight="semibold">Add location for report details</AppText>
            <AppText size={10} tone="muted">The scan works without GPS; saving a report needs a location.</AppText>
          </View>
          <Pressable accessibilityRole="button" onPress={attachLocation} style={styles.attachLocation}>
            <AppText size={10} tone="accent" weight="semibold">Attach</AppText>
          </Pressable>
        </Panel>
      )}
      {locationError ? <AppText size={11} tone="warning">{locationError}</AppText> : null}
      {!user ? (
        <Panel style={styles.authNotice}>
          <Ionicons name="lock-closed-outline" size={17} color={colors.warning} />
          <View style={styles.locationCopy}>
            <AppText size={11} weight="semibold">AI scans require an account</AppText>
            <AppText size={10} tone="muted">Sign in to use the authenticated scan service and save shared reports.</AppText>
          </View>
          <Pressable accessibilityRole="button" onPress={() => router.push('/(auth)/login')} style={styles.attachLocation}>
            <AppText size={10} tone="accent" weight="semibold">Log in</AppText>
          </Pressable>
        </Panel>
      ) : null}

      {!result ? (
        mode === 'live' ? (
          <View style={styles.cameraFrame}>
            {cameraOpen ? (
              <>
                <CameraView
                  ref={cameraRef}
                  style={StyleSheet.absoluteFill}
                  facing="back"
                  onCameraReady={() => setCameraReady(true)}
                >
                  <DetectionOverlay potholes={frameDetections.potholes} />
                </CameraView>
                <View style={styles.cameraStatus}>
                  <View style={[styles.liveDot, { backgroundColor: isScanning ? colors.success : colors.mutedForeground }]} />
                  <AppText size={10} weight="semibold">{isScanning ? `AI scan · frame ${frameCount + 1}/10` : 'Camera ready'}</AppText>
                </View>
                <Pressable accessibilityRole="button" onPress={() => { setIsScanning(false); setCameraOpen(false); setCameraReady(false); if (framesScanned.current > 0) void finishEmptyScan(); }} style={styles.stopButton}>
                  <Ionicons name="stop" size={16} color="#FFFFFF" />
                  <AppText size={11} weight="semibold" style={styles.whiteText}>Stop scan</AppText>
                </Pressable>
              </>
            ) : (
              <View style={styles.emptyCamera}>
                <View style={styles.cameraIcon}><Ionicons name="scan-outline" size={25} color={colors.accent} /></View>
                <AppText size={14} weight="semibold">{noPothole ? 'No pothole detected' : 'Live camera scan'}</AppText>
                <AppText size={11} tone="muted" style={styles.centerText}>
                  The camera sends a compressed frame to your authenticated scan service about once a second for up to 10 seconds.
                </AppText>
                <AppButton
                  title={noPothole ? 'Retry live scan' : 'Start live scan'}
                  icon="camera-outline"
                  onPress={beginLiveScan}
                  style={styles.startScanButton}
                />
              </View>
            )}
          </View>
        ) : (
          <Panel style={styles.uploadPanel}>
            <View style={styles.cameraIcon}><Ionicons name="image-outline" size={25} color={colors.accent} /></View>
            <AppText size={14} weight="semibold">{noPothole ? 'No pothole detected' : 'Choose a road photo'}</AppText>
            <AppText size={11} tone="muted" style={styles.centerText}>
              {noPothole ? 'Try another image with the damaged road clearly in frame.' : 'Images are resized and compressed before upload. Blurry photos and files over 8 MB are rejected.'}
            </AppText>
            <AppButton
              title={scanBusy ? 'Scanning image…' : noPothole ? 'Retry with another image' : 'Choose image'}
              icon={scanBusy ? undefined : 'images-outline'}
              loading={scanBusy}
              onPress={chooseImage}
              style={styles.startScanButton}
            />
          </Panel>
        )
      ) : (
        <Animated.View entering={FadeInDown.duration(260)} style={styles.resultGroup}>
          {photoUri ? (
            <DetectionPreview uri={photoUri} potholes={result.potholes} />
          ) : null}
          {result.potholes.length === 0 ? (
            <Panel style={styles.noDetection}>
              <View style={styles.noDetectionIcon}><Ionicons name="search-outline" size={21} color={colors.warning} /></View>
              <View style={styles.locationCopy}>
                <AppText size={14} weight="semibold">No pothole detected</AppText>
                <AppText size={11} tone="muted">Try another photo or start a new live scan.</AppText>
              </View>
              <AppButton title="Retry" icon="refresh-outline" variant="secondary" onPress={retry} style={styles.retryButton} />
            </Panel>
          ) : (
            <>
              <Panel style={styles.resultCard}>
                <View style={styles.resultHead}>
                  <View>
                    <AppText size={10} tone="muted" weight="semibold">AI SCAN RESULT</AppText>
                    <AppText size={17} weight="bold">{result.potholes.length} pothole{result.potholes.length === 1 ? '' : 's'} detected</AppText>
                  </View>
                  <SeverityBadge severity={result.overall_severity === 'None' ? 'Low' : result.overall_severity} />
                </View>
                <AppText size={11} tone="muted">
                  Max confidence {Math.max(...result.potholes.map((item) => item.confidence))}% · {new Date().toLocaleString()}
                </AppText>
                <View style={styles.resultMeta}>
                  <Ionicons name="location-outline" size={15} color={geo ? colors.success : colors.warning} />
                  <AppText size={11} tone={geo ? 'muted' : 'warning'} numberOfLines={2} style={styles.locationCopy}>
                    {geo?.address ?? 'Attach GPS to include the address and save this report.'}
                  </AppText>
                </View>
                <View style={styles.detectionList}>
                  {result.potholes.map((pothole, index) => (
                    <View key={`${index}-${pothole.confidence}`} style={styles.detectionRow}>
                      <SeverityBadge severity={pothole.severity} />
                      <AppText size={10} tone="muted" style={styles.detectionDetail}>
                        #{index + 1} · {pothole.confidence}% confidence · {pothole.area_percent.toFixed(1)}% of image
                      </AppText>
                    </View>
                  ))}
                </View>
              </Panel>
              <Field
                label="Optional note"
                value={note}
                onChangeText={setNote}
                placeholder="Nearby landmark or road name"
                maxLength={500}
              />
              <Panel style={styles.privacyPanel}>
                <Ionicons name={privacyReady ? 'shield-checkmark-outline' : 'eye-off-outline'} size={18} color={privacyReady ? colors.success : colors.mutedForeground} />
                <View style={styles.privacyCopy}>
                  <AppText size={11} weight="semibold">{privacyReady ? 'Automatic face and plate blur applied' : 'Review the photo before saving'}</AppText>
                  <AppText size={10} tone="muted">
                    {privacyReady ? 'The detector can miss details; check the image.' : 'If privacy blur is unavailable, keep identifying people and plates out of frame.'}
                  </AppText>
                  <Pressable
                    accessibilityRole="checkbox"
                    accessibilityState={{ checked: privacyReviewed }}
                    onPress={() => setPrivacyReviewed((value) => !value)}
                    style={styles.reviewRow}
                  >
                    <Ionicons name={privacyReviewed ? 'checkbox' : 'square-outline'} size={18} color={privacyReviewed ? colors.accent : colors.mutedForeground} />
                    <AppText size={10} tone="muted" style={styles.reviewLabel}>I reviewed this image and it is safe to share.</AppText>
                  </Pressable>
                </View>
              </Panel>
              {settings.autoSaveScans && !savedReportId ? (
                <AppText size={10} tone="muted" style={styles.autoSaveNote}>
                  Auto-save requires GPS and the privacy-blur service. If either is unavailable, save manually after reviewing the photo.
                </AppText>
              ) : null}
              {savedReportId ? (
          <Panel style={styles.savedBanner}>
                  <Ionicons name="checkmark-circle" size={19} color={colors.success} />
            <View style={styles.locationCopy}>
              <AppText size={12} weight="semibold" tone="success">Saved</AppText>
              <AppText size={10} tone="muted">{saveMessage}</AppText>
            </View>
                  <Pressable accessibilityRole="button" onPress={() => router.push({ pathname: '/report/[id]', params: { id: savedReportId } })}>
                    <AppText size={11} tone="accent" weight="semibold">Open report</AppText>
                  </Pressable>
                </Panel>
              ) : (
                <View style={styles.resultActions}>
                  <AppButton title="Discard" variant="secondary" onPress={discardResult} style={styles.halfButton} />
                  <AppButton
                    title={saveBusy ? 'Saving…' : 'Save Report'}
                    icon="cloud-upload-outline"
                    loading={saveBusy}
                    disabled={!geo || !privacyReviewed}
                    onPress={saveReport}
                    style={styles.halfButton}
                  />
                </View>
              )}
            </>
          )}
          <Pressable accessibilityRole="button" onPress={() => void Share.share({ message: `PotHoleRadar scan: ${result.overall_severity}, ${result.potholes.length} potholes detected.` })} style={styles.shareScan}>
            <Ionicons name="share-social-outline" size={15} color={colors.accent} />
            <AppText size={11} tone="accent" weight="semibold">Share scan summary</AppText>
          </Pressable>
        </Animated.View>
      )}
      {scanError ? <AppText size={11} tone="warning" style={styles.error}>{scanError}</AppText> : null}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 12, paddingBottom: 32, gap: 14 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  headerTitle: { flex: 1 },
  historyIcon: { width: 38, height: 38, alignItems: 'center', justifyContent: 'center' },
  modeRow: { flexDirection: 'row', gap: 7 },
  locationCard: { flexDirection: 'row', alignItems: 'center', gap: 9, padding: 11 },
  authNotice: { flexDirection: 'row', alignItems: 'center', gap: 9, padding: 11 },
  locationCopy: { flex: 1, gap: 3 },
  refreshLocation: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  attachLocation: { minHeight: 32, justifyContent: 'center', paddingHorizontal: 7 },
  cameraFrame: { height: 380, borderRadius: 22, overflow: 'hidden', backgroundColor: '#131313', borderWidth: 1, borderColor: '#292929' },
  emptyCamera: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 22, gap: 10 },
  cameraIcon: { width: 52, height: 52, borderRadius: 17, alignItems: 'center', justifyContent: 'center', backgroundColor: '#2A1A13' },
  centerText: { maxWidth: 310, lineHeight: 17, textAlign: 'center' },
  startScanButton: { minWidth: 190, marginTop: 4 },
  cameraStatus: { position: 'absolute', top: 12, left: 12, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 100, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(10,10,10,0.76)' },
  liveDot: { width: 7, height: 7, borderRadius: 4 },
  stopButton: { position: 'absolute', bottom: 13, alignSelf: 'center', backgroundColor: '#B91C1C', borderRadius: 99, paddingHorizontal: 14, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 6 },
  whiteText: { color: '#FFFFFF' },
  uploadPanel: { minHeight: 250, alignItems: 'center', justifyContent: 'center', gap: 10, padding: 20 },
  resultGroup: { gap: 12 },
  resultCard: { gap: 9 },
  resultHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  resultMeta: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  detectionList: { gap: 6, paddingTop: 2 },
  detectionRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  detectionDetail: { flex: 1 },
  privacyPanel: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, padding: 12 },
  privacyCopy: { flex: 1, gap: 5 },
  reviewRow: { flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 27 },
  reviewLabel: { flex: 1 },
  autoSaveNote: { lineHeight: 15 },
  resultActions: { flexDirection: 'row', gap: 9 },
  halfButton: { flex: 1 },
  noDetection: { flexDirection: 'row', alignItems: 'center', gap: 10, flexWrap: 'wrap' },
  noDetectionIcon: { width: 37, height: 37, alignItems: 'center', justifyContent: 'center', borderRadius: 12, backgroundColor: '#322813' },
  retryButton: { marginLeft: 'auto' },
  savedBanner: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  shareScan: { alignSelf: 'center', minHeight: 32, flexDirection: 'row', alignItems: 'center', gap: 6 },
  error: { lineHeight: 16 },
});
