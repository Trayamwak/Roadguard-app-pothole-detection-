---
name: Expo web preview and native maps
description: Replit Expo web previews need platform-separated map implementations and an immediately rendering root layout.
---

Keep native-only packages such as `react-native-maps` inside platform-specific components, not shared Expo Router route modules. Provide a web implementation and a generic typed fallback so Metro and TypeScript resolve the shared import independently.

Do not block the root layout on optional font loading. Render the app shell immediately and let device/system fonts serve as a fallback.

**Why:** In this Expo SDK 57 workspace, Metro's web route bundle still reached native map imports from a shared route and failed on React Native internals. A font-gated root layout also left the web preview blank.

**How to apply:** For native-only UI, use a platform-neutral route plus `*.native.tsx` and `*.web.tsx` components. Keep the root layout visible while optional assets load.
