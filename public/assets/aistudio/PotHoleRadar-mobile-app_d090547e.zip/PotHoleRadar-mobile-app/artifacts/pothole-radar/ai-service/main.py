"""Optional FastAPI service for pothole photo severity assessment.

Set YOLO_WEIGHTS to a YOLOv8 checkpoint trained on a pothole dataset. The
service deliberately fails closed when no weights or Firebase token verifier
are configured; it does not invent an AI result.
"""

from __future__ import annotations

import io
import logging
import math
import os
import time
from collections import defaultdict, deque
from typing import Literal

from fastapi import Depends, FastAPI, File, Header, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import BaseModel, Field
from PIL import Image, UnidentifiedImageError
import httpx

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("pothole-severity")

app = FastAPI(
    title="PotHoleRadar Severity Service",
    version="1.0.0",
    description="Firebase-authenticated YOLOv8 pothole image assessment.",
)

allowed_origins = [
    origin.strip()
    for origin in os.getenv("CORS_ORIGINS", "").split(",")
    if origin.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["POST", "GET"],
    allow_headers=["Authorization", "Content-Type"],
)

MAX_IMAGE_BYTES = 8 * 1024 * 1024
RATE_WINDOW_SECONDS = 60 * 60
RATE_LIMIT_PER_HOUR = 12
requests_by_ip: dict[str, deque[float]] = defaultdict(deque)


class SeverityResult(BaseModel):
    severity: Literal["Low", "Medium", "High", "Critical"]
    confidence: int = Field(ge=0, le=100)
    reason: str


class PotholeDetection(BaseModel):
    bbox: list[float] = Field(description="Normalized x, y, width, height in the 0..1 range.")
    confidence: int = Field(ge=0, le=100)
    severity: Literal["Low", "Medium", "High", "Critical"]
    area_percent: float = Field(ge=0, le=100)


class DetectResponse(BaseModel):
    potholes: list[PotholeDetection]
    overall_severity: Literal["Low", "Medium", "High", "Critical", "None"]


class SafeRouteRequest(BaseModel):
    origin_lat: float = Field(ge=-90, le=90)
    origin_lng: float = Field(ge=-180, le=180)
    destination: str = Field(min_length=2, max_length=200)


class RouteWarning(BaseModel):
    report_id: str
    lat: float
    lng: float
    severity: Literal["High", "Critical"]


class SafeRoute(BaseModel):
    polyline: str
    points: list[dict[str, float]]
    distance_meters: int
    duration_seconds: int
    warning_count: int
    warnings: list[RouteWarning]
    score_seconds: int


class SafeRouteResponse(BaseModel):
    routes: list[SafeRoute]
    notice: str


try:
    from ultralytics import YOLO

    weights_path = os.getenv("YOLO_WEIGHTS", "")
    model = YOLO(weights_path) if weights_path and os.path.isfile(weights_path) else None
except Exception as exc:  # pragma: no cover - depends on optional native ML packages
    logger.exception("Could not load the configured YOLO model: %s", exc)
    model = None

firebase_auth = None
firestore_db = None
project_id = os.getenv("FIREBASE_PROJECT_ID")
if project_id:
    try:
        import firebase_admin
        from firebase_admin import auth as firebase_auth, firestore

        if not firebase_admin._apps:
            firebase_admin.initialize_app(options={"projectId": project_id})
        firestore_db = firestore.client()
    except Exception:
        logger.exception("Firebase Admin token verification could not be initialized")
        firebase_auth = None


def verify_firebase_user(authorization: str | None = Header(default=None)) -> str:
    """Require a valid Firebase ID token before accepting an image."""
    if not firebase_auth or not project_id:
        raise HTTPException(
            status_code=503,
            detail="Configure Firebase Admin credentials and FIREBASE_PROJECT_ID.",
        )
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="A Firebase ID token is required.")
    token = authorization.removeprefix("Bearer ").strip()
    try:
        return firebase_auth.verify_id_token(token)["uid"]
    except Exception as exc:
        raise HTTPException(status_code=401, detail="The Firebase ID token is invalid.") from exc


def check_rate_limit(
    request: Request,
    user_id: str,
    *,
    limit: int = RATE_LIMIT_PER_HOUR,
    window_seconds: int = RATE_WINDOW_SECONDS,
    bucket: str = "general",
) -> None:
    """Lightweight per-process limit; use a shared Redis limiter in production."""
    now = time.time()
    key = f"{bucket}:{user_id}:{request.client.host if request.client else 'unknown'}"
    entries = requests_by_ip[key]
    while entries and now - entries[0] > window_seconds:
        entries.popleft()
    if len(entries) >= limit:
        raise HTTPException(status_code=429, detail="Request limit reached. Try again shortly.")
    entries.append(now)


def assess_detection(image: Image.Image) -> SeverityResult:
    """Turn YOLO boxes into a severity estimate based on image occupancy."""
    if model is None:
        raise HTTPException(
            status_code=503,
            detail="No YOLOv8 pothole checkpoint is configured. Set YOLO_WEIGHTS first.",
        )

    predictions = model.predict(source=image, verbose=False)
    result = predictions[0]
    names = result.names
    allowed_names = {
        item.strip().lower()
        for item in os.getenv("YOLO_CLASS_NAMES", "pothole").split(",")
        if item.strip()
    }
    if result.boxes is None or len(result.boxes) == 0:
        return SeverityResult(
            severity="Low",
            confidence=20,
            reason="No pothole-shaped object was detected in this image.",
        )

    image_area = max(1, image.width * image.height)
    candidates: list[tuple[float, float]] = []
    for box in result.boxes:
        class_id = int(box.cls.item())
        class_name = str(names.get(class_id, class_id)).lower()
        if not any(allowed in class_name for allowed in allowed_names):
            continue
        x1, y1, x2, y2 = [float(value) for value in box.xyxy[0].tolist()]
        area_ratio = max(0.0, (x2 - x1) * (y2 - y1)) / image_area
        candidates.append((area_ratio, float(box.conf.item())))

    if not candidates:
        return SeverityResult(
            severity="Low",
            confidence=20,
            reason="The model did not identify a pothole in this image.",
        )

    area_ratio, model_confidence = max(candidates, key=lambda candidate: candidate[0])
    if area_ratio >= 0.20:
        severity = "Critical"
        size_description = "very large"
    elif area_ratio >= 0.09:
        severity = "High"
        size_description = "large"
    elif area_ratio >= 0.025:
        severity = "Medium"
        size_description = "moderate"
    else:
        severity = "Low"
        size_description = "small"
    return SeverityResult(
        severity=severity,
        confidence=round(model_confidence * 100),
        reason=f"The model found a {size_description} pothole occupying {area_ratio:.0%} of the photo.",
    )


def classify_pothole_severity(area_ratio: float, confidence: float, center_y: float, image_height: int) -> str:
    """Estimate severity from area, model confidence, and a weak perspective cue.

    The lower-frame cue is only an image-position heuristic, not measured depth.
    A trained depth model or human assessment is needed for reliable depth.
    """
    area_score = min(max(area_ratio / 0.20, 0.0), 1.0)
    confidence_score = min(max(confidence, 0.0), 1.0)
    lower_frame_ratio = center_y / max(1, image_height)
    depth_cue = min(max((lower_frame_ratio - 0.40) / 0.60, 0.0), 1.0)
    combined = 0.65 * area_score + 0.25 * confidence_score + 0.10 * depth_cue
    if combined >= 0.82:
        return "Critical"
    if combined >= 0.60:
        return "High"
    if combined >= 0.34:
        return "Medium"
    return "Low"


def detect_potholes(image: Image.Image) -> DetectResponse:
    """Return normalized boxes and a severity label for each model detection."""
    if model is None:
        raise HTTPException(
            status_code=503,
            detail="No YOLOv8 pothole checkpoint is configured. Set YOLO_WEIGHTS first.",
        )
    try:
        import cv2
        import numpy as np
    except ImportError as exc:
        raise HTTPException(status_code=503, detail="Install OpenCV before using live detection.") from exc

    gray = cv2.cvtColor(np.array(image.convert("RGB")), cv2.COLOR_RGB2GRAY)
    if float(cv2.Laplacian(gray, cv2.CV_64F).var()) < 8:
        raise HTTPException(status_code=422, detail="This image looks blurry. Hold still and try again.")

    prediction = model.predict(source=image, verbose=False)[0]
    allowed_names = {
        item.strip().lower()
        for item in os.getenv("YOLO_CLASS_NAMES", "pothole").split(",")
        if item.strip()
    }
    detections: list[PotholeDetection] = []
    if prediction.boxes is not None:
        image_area = max(1, image.width * image.height)
        for box in prediction.boxes:
            class_id = int(box.cls.item())
            class_name = str(prediction.names.get(class_id, class_id)).lower()
            if not any(allowed in class_name for allowed in allowed_names):
                continue
            x1, y1, x2, y2 = [float(value) for value in box.xyxy[0].tolist()]
            width = max(0.0, x2 - x1)
            height = max(0.0, y2 - y1)
            area_ratio = width * height / image_area
            confidence = min(max(float(box.conf.item()), 0.0), 1.0)
            severity = classify_pothole_severity(area_ratio, confidence, (y1 + y2) / 2, image.height)
            detections.append(
                PotholeDetection(
                    bbox=[
                        min(max(x1 / image.width, 0.0), 1.0),
                        min(max(y1 / image.height, 0.0), 1.0),
                        min(max(width / image.width, 0.0), 1.0),
                        min(max(height / image.height, 0.0), 1.0),
                    ],
                    confidence=round(confidence * 100),
                    severity=severity,
                    area_percent=round(area_ratio * 100, 2),
                )
            )
    rank = {"Low": 1, "Medium": 2, "High": 3, "Critical": 4}
    overall = max((item.severity for item in detections), key=lambda value: rank[value], default="None")
    return DetectResponse(potholes=detections, overall_severity=overall)


def decode_polyline(encoded: str) -> list[tuple[float, float]]:
    """Decode Google's encoded polyline into latitude/longitude pairs."""
    points: list[tuple[float, float]] = []
    index = latitude = longitude = 0
    while index < len(encoded):
        values = []
        for _ in range(2):
            result = shift = 0
            while True:
                byte = ord(encoded[index]) - 63
                index += 1
                result |= (byte & 0x1F) << shift
                shift += 5
                if byte < 0x20:
                    break
            values.append(~(result >> 1) if result & 1 else result >> 1)
        latitude += values[0]
        longitude += values[1]
        points.append((latitude / 1e5, longitude / 1e5))
    return points


def distance_point_to_segment_meters(point: tuple[float, float], start: tuple[float, float], end: tuple[float, float]) -> float:
    """Approximate point-to-road-segment distance in a local meter projection."""
    lat, lng = point
    reference_lat = math.radians(lat)
    scale_x = 111_320 * math.cos(reference_lat)
    scale_y = 111_320
    px, py = lng * scale_x, lat * scale_y
    ax, ay = start[1] * scale_x, start[0] * scale_y
    bx, by = end[1] * scale_x, end[0] * scale_y
    dx, dy = bx - ax, by - ay
    length_squared = dx * dx + dy * dy
    if length_squared == 0:
        return math.hypot(px - ax, py - ay)
    fraction = min(max(((px - ax) * dx + (py - ay) * dy) / length_squared, 0.0), 1.0)
    return math.hypot(px - (ax + fraction * dx), py - (ay + fraction * dy))


def distance_to_route_meters(point: tuple[float, float], route: list[tuple[float, float]]) -> float:
    if not route:
        return float("inf")
    if len(route) == 1:
        return distance_point_to_segment_meters(point, route[0], route[0])
    return min(distance_point_to_segment_meters(point, route[i], route[i + 1]) for i in range(len(route) - 1))


def blur_faces_and_plates(image: Image.Image) -> tuple[Image.Image, int]:
    """Blur face and plate candidates with OpenCV Haar cascades.

    This is a privacy aid, not a guarantee. The app still requires a human
    review before upload because small/angled plates may not be detected.
    """
    try:
        import cv2
        import numpy as np
    except ImportError as exc:
        raise HTTPException(status_code=503, detail="Install OpenCV for privacy blurring.") from exc

    rgb = np.array(image.convert("RGB"))
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    cascade_root = cv2.data.haarcascades
    detectors = [
        cv2.CascadeClassifier(os.path.join(cascade_root, "haarcascade_frontalface_default.xml")),
        cv2.CascadeClassifier(os.path.join(cascade_root, "haarcascade_russian_plate_number.xml")),
    ]
    rectangles: list[tuple[int, int, int, int]] = []
    for detector in detectors:
        if detector.empty():
            continue
        found = detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=(18, 12))
        rectangles.extend(tuple(int(value) for value in rectangle) for rectangle in found)

    for x, y, width, height in rectangles:
        pad_x = max(4, int(width * 0.12))
        pad_y = max(4, int(height * 0.12))
        left = max(0, x - pad_x)
        top = max(0, y - pad_y)
        right = min(bgr.shape[1], x + width + pad_x)
        bottom = min(bgr.shape[0], y + height + pad_y)
        region = bgr[top:bottom, left:right]
        if region.size:
            kernel = max(21, (min(region.shape[:2]) // 3) | 1)
            bgr[top:bottom, left:right] = cv2.GaussianBlur(region, (kernel, kernel), 0)
    result = Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
    return result, len(rectangles)


async def read_valid_image(photo: UploadFile) -> Image.Image:
    if photo.content_type not in {"image/jpeg", "image/png", "image/webp"}:
        raise HTTPException(status_code=415, detail="Upload a JPEG, PNG, or WebP image.")
    image_bytes = await photo.read(MAX_IMAGE_BYTES + 1)
    if not image_bytes or len(image_bytes) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="Images must be smaller than 8 MB.")
    try:
        return Image.open(io.BytesIO(image_bytes)).convert("RGB")
    except (UnidentifiedImageError, OSError) as exc:
        raise HTTPException(status_code=400, detail="The uploaded file is not a valid image.") from exc


@app.get("/health")
async def health() -> dict[str, str]:
    return {
        "status": "ok",
        "model": "ready" if model is not None else "missing",
        "auth": "ready" if firebase_auth is not None else "missing",
    }


@app.post("/analyze", response_model=SeverityResult)
async def analyze_photo(
    request: Request,
    photo: UploadFile = File(...),
    user_id: str = Depends(verify_firebase_user),
) -> SeverityResult:
    check_rate_limit(request, user_id, bucket="analyze")
    image = await read_valid_image(photo)
    return assess_detection(image)


@app.post("/detect", response_model=DetectResponse)
async def detect_photo(
    request: Request,
    photo: UploadFile = File(...),
    user_id: str = Depends(verify_firebase_user),
) -> DetectResponse:
    check_rate_limit(request, user_id, limit=90, window_seconds=60, bucket="live-detect")
    image = await read_valid_image(photo)
    return detect_potholes(image)


@app.post("/safe-route", response_model=SafeRouteResponse)
async def safe_route(
    request: Request,
    body: SafeRouteRequest,
    user_id: str = Depends(verify_firebase_user),
) -> SafeRouteResponse:
    check_rate_limit(request, user_id, limit=10, window_seconds=60, bucket="safe-route")
    api_key = os.getenv("GOOGLE_MAPS_SERVER_API_KEY", "")
    if not api_key:
        raise HTTPException(status_code=503, detail="Configure GOOGLE_MAPS_SERVER_API_KEY on the API server.")
    if firestore_db is None:
        raise HTTPException(status_code=503, detail="Configure Firebase Admin access before calculating safe routes.")

    params = {
        "origin": f"{body.origin_lat},{body.origin_lng}",
        "destination": body.destination,
        "mode": "driving",
        "alternatives": "true",
        "key": api_key,
    }
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.get("https://maps.googleapis.com/maps/api/directions/json", params=params)
            response.raise_for_status()
            directions = response.json()
    except httpx.HTTPError as exc:
        logger.exception("Google Directions request failed")
        raise HTTPException(status_code=502, detail="Google Directions could not be reached. Try again.") from exc
    if directions.get("status") != "OK":
        message = directions.get("error_message") or directions.get("status") or "No route was found."
        raise HTTPException(status_code=422, detail=message)

    warnings: list[RouteWarning] = []
    try:
        for item in firestore_db.collection("reports").where("status", "==", "open").limit(1500).stream():
            data = item.to_dict() or {}
            if data.get("severity") not in {"High", "Critical"}:
                continue
            try:
                warnings.append(
                    RouteWarning(
                        report_id=item.id,
                        lat=float(data["lat"]),
                        lng=float(data["lng"]),
                        severity=data["severity"],
                    )
                )
            except (KeyError, TypeError, ValueError):
                continue
    except Exception as exc:
        logger.exception("Could not read open pothole reports for safe routing")
        raise HTTPException(status_code=503, detail="The report database is unavailable for route safety checks.") from exc

    ranked: list[SafeRoute] = []
    for route in directions.get("routes", []):
        encoded = route.get("overview_polyline", {}).get("points", "")
        points = decode_polyline(encoded)
        nearby_warnings = [
            warning
            for warning in warnings
            if distance_to_route_meters((warning.lat, warning.lng), points) <= 75
        ]
        leg = (route.get("legs") or [{}])[0]
        distance_meters = int(leg.get("distance", {}).get("value", 0))
        duration_seconds = int(leg.get("duration", {}).get("value", 0))
        penalty = sum(1200 if warning.severity == "Critical" else 600 for warning in nearby_warnings)
        ranked.append(
            SafeRoute(
                polyline=encoded,
                points=[{"latitude": lat, "longitude": lng} for lat, lng in points],
                distance_meters=distance_meters,
                duration_seconds=duration_seconds,
                warning_count=len(nearby_warnings),
                warnings=nearby_warnings,
                score_seconds=duration_seconds + penalty,
            )
        )
    ranked.sort(key=lambda route: route.score_seconds)
    return SafeRouteResponse(
        routes=ranked[:3],
        notice="Routes are ranked by ETA plus known open High/Critical potholes near the path. Reports may be incomplete; drive carefully.",
    )


@app.post("/privacy-blur")
async def privacy_blur(
    request: Request,
    photo: UploadFile = File(...),
    user_id: str = Depends(verify_firebase_user),
) -> Response:
    check_rate_limit(request, user_id)
    image = await read_valid_image(photo)
    blurred, count = blur_faces_and_plates(image)
    output = io.BytesIO()
    blurred.save(output, format="JPEG", quality=88, optimize=True)
    return Response(
        content=output.getvalue(),
        media_type="image/jpeg",
        headers={"X-Redactions-Count": str(count), "Cache-Control": "no-store"},
    )
