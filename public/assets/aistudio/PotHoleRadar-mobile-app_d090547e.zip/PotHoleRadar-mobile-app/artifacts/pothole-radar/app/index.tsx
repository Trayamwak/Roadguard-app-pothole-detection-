import React, { useEffect } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { AppButton, AppScreen, AppText, Panel } from '@/components/AppUI';
import { useApp } from '@/providers/AppProvider';
import { useColors } from '@/hooks/useColors';

function RadarRing({ delay = 0 }: { delay?: number }) {
  const progress = useSharedValue(0);
  useEffect(() => {
    progress.value = withDelay(
      delay,
      withRepeat(withTiming(1, { duration: 2600 }), -1, false),
    );
  }, [delay, progress]);
  const animatedStyle = useAnimatedStyle(() => ({
    opacity: 0.34 * (1 - progress.value),
    transform: [{ scale: 0.48 + progress.value * 1.15 }],
  }));
  const colors = useColors();
  return (
    <Animated.View
      pointerEvents="none"
      style={[styles.radarRing, { borderColor: colors.primary }, animatedStyle]}
    />
  );
}

export default function WelcomeScreen() {
  const colors = useColors();
  const { user, guestMode, setGuestMode } = useApp();
  useEffect(() => {
    if (user || guestMode) router.replace('/(tabs)');
  }, [guestMode, user]);

  const goTo = async (path: '/(auth)/signup' | '/(auth)/login') => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => undefined);
    router.push(path);
  };

  return (
    <AppScreen contentStyle={styles.content}>
      <View style={styles.topRow}>
        <View style={[styles.brandMark, { backgroundColor: '#291311', borderColor: '#4B211C' }]}>
          <Ionicons name="radio-outline" size={21} color={colors.accent} />
        </View>
        <AppText size={14} weight="bold" style={styles.brandText}>POTHOLE RADAR</AppText>
        <View style={styles.topSpacer} />
        <View style={[styles.livePill, { borderColor: colors.border }]}>
          <View style={[styles.liveDot, { backgroundColor: colors.success }]} />
          <AppText size={10} tone="muted" weight="semibold">COMMUNITY MAP</AppText>
        </View>
      </View>

      <View style={styles.hero}>
        <View style={styles.radarGraphic}>
          <RadarRing />
          <RadarRing delay={850} />
          <RadarRing delay={1700} />
          <LinearGradient
            colors={['#2D1411', '#191111', '#101010']}
            style={[styles.radarCore, { borderColor: '#4B241C' }]}
          >
            <View style={styles.radarCrosshair} />
            <Ionicons name="location" size={41} color={colors.primary} />
            <View style={[styles.radarCenterDot, { backgroundColor: colors.accent }]} />
          </LinearGradient>
          <View style={[styles.signalDot, styles.signalOne, { backgroundColor: colors.accent }]} />
          <View style={[styles.signalDot, styles.signalTwo, { backgroundColor: colors.primary }]} />
        </View>
        <View style={styles.heroCopy}>
          <AppText size={12} tone="accent" weight="bold" style={styles.eyebrow}>
            YOUR CITY, A LITTLE SAFER
          </AppText>
          <AppText size={36} weight="bold" style={styles.heroTitle}>
            Welcome to{'\n'}PotHoleRadar
          </AppText>
          <AppText size={16} tone="muted" style={styles.tagline}>
            Spot it. Report it. Fix it.
          </AppText>
        </View>
      </View>

      <Panel style={styles.permissionPanel}>
        <AppText size={14} weight="semibold">You’re in control</AppText>
        <View style={styles.permissionRow}>
          <Ionicons name="camera-outline" size={17} color={colors.accent} />
          <AppText size={12} tone="muted" style={styles.permissionText}>
            Camera and location are only requested when you report a road issue.
          </AppText>
        </View>
        <View style={styles.permissionRow}>
          <Ionicons name="speedometer-outline" size={17} color={colors.accent} />
          <AppText size={12} tone="muted" style={styles.permissionText}>
            Motion is used only while Drive Mode is on and the app is open.
          </AppText>
        </View>
      </Panel>

      <View style={styles.actions}>
        <AppButton title="Get Started" icon="arrow-forward" onPress={() => goTo('/(auth)/signup')} />
        <AppButton title="Log in" variant="secondary" onPress={() => goTo('/(auth)/login')} />
        <Pressable
          accessibilityRole="button"
          onPress={() => {
            setGuestMode(true);
            router.replace('/(tabs)');
          }}
          style={styles.offlineButton}
        >
          <AppText size={13} tone="muted" weight="medium">Explore without an account</AppText>
        </Pressable>
      </View>
      <AppText size={10} tone="muted" style={styles.footer}>
        Community reports help cities prioritize repairs. Always report from a safe place.
      </AppText>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  content: { flex: 1, justifyContent: 'space-between', paddingTop: 14, paddingBottom: 20, gap: 12 },
  topRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  brandMark: { width: 36, height: 36, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  brandText: { letterSpacing: 1.2, fontSize: 11 },
  topSpacer: { flex: 1 },
  livePill: { borderWidth: 1, borderRadius: 100, paddingVertical: 7, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 7 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  hero: { minHeight: 350, justifyContent: 'center' },
  radarGraphic: { height: 224, alignItems: 'center', justifyContent: 'center', marginTop: 3 },
  radarRing: { position: 'absolute', width: 172, height: 172, borderWidth: 1, borderRadius: 100 },
  radarCore: { width: 126, height: 126, borderWidth: 1, borderRadius: 63, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  radarCrosshair: { position: 'absolute', width: 1, height: 100, backgroundColor: 'rgba(255,255,255,0.12)' },
  radarCenterDot: { position: 'absolute', width: 7, height: 7, borderRadius: 4 },
  signalDot: { position: 'absolute', width: 8, height: 8, borderRadius: 4 },
  signalOne: { top: 44, right: '28%' },
  signalTwo: { bottom: 48, left: '27%' },
  heroCopy: { alignItems: 'center', marginTop: 10 },
  eyebrow: { letterSpacing: 2.1, marginBottom: 9 },
  heroTitle: { textAlign: 'center', lineHeight: 42, letterSpacing: -1.2 },
  tagline: { marginTop: 11, letterSpacing: 0.15 },
  permissionPanel: { padding: 15, gap: 11 },
  permissionRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 9 },
  permissionText: { flex: 1, lineHeight: 17 },
  actions: { gap: 10 },
  offlineButton: { alignItems: 'center', paddingVertical: 5, minHeight: 32, justifyContent: 'center' },
  footer: { textAlign: 'center', lineHeight: 15, paddingHorizontal: 12 },
});
