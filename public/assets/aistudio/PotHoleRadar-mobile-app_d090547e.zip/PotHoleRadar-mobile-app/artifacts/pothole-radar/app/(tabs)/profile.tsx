import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { AppButton, AppScreen, AppText, Panel, PageTitle, StatTile } from '@/components/AppUI';
import { auth } from '@/lib/firebase';
import { useApp } from '@/providers/AppProvider';
import { useColors } from '@/hooks/useColors';

export default function ProfileScreen() {
  const colors = useColors();
  const { user, guestMode, reports } = useApp();
  const [admin, setAdmin] = useState(false);
  React.useEffect(() => {
    if (!auth?.currentUser) {
      setAdmin(false);
      return;
    }
    auth.currentUser.getIdTokenResult().then((token) => setAdmin(token.claims.admin === true)).catch(() => setAdmin(false));
  }, [user]);
  const mine = reports.filter((report) => report.userId === (user?.uid ?? (guestMode ? 'guest' : '')));
  const points = mine.length * 25;
  const badges = useMemo(() => {
    const result: string[] = [];
    if (mine.length > 0) result.push('First report');
    if (mine.length >= 5) result.push('Street scout');
    if (mine.length >= 20) result.push('Road guardian');
    return result;
  }, [mine.length]);
  const leaderboard = useMemo(() => {
    const people = new Map<string, { label: string; count: number }>();
    for (const report of reports) {
      if (!report.userId || report.userId === 'guest') continue;
      const person = people.get(report.userId) ?? { label: report.authorLabel, count: 0 };
      person.count += 1;
      if (report.authorLabel !== 'Anonymous contributor') person.label = report.authorLabel;
      people.set(report.userId, person);
    }
    return [...people.entries()]
      .map(([id, person]) => ({ id, ...person }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [reports]);
  const displayName = user?.displayName || user?.email?.split('@')[0] || 'Road watcher';
  const initials = displayName.slice(0, 1).toUpperCase();

  return (
    <AppScreen scroll contentStyle={styles.content}>
      <PageTitle eyebrow="Your impact" title="Profile" subtitle="Every confirmed report helps a city see the problem." />
      <Panel style={styles.identity}>
        <View style={[styles.avatar, { backgroundColor: '#321512', borderColor: '#66302A' }]}>
          <AppText size={27} tone="accent" weight="bold">{initials}</AppText>
        </View>
        <View style={styles.identityCopy}>
          <AppText size={18} weight="bold">{displayName}</AppText>
          <AppText size={12} tone="muted">{user?.email || (guestMode ? 'Guest · local only' : 'Sign in to sync reports')}</AppText>
        </View>
        <Pressable accessibilityRole="button" accessibilityLabel="Open settings" onPress={() => router.push('/settings')}>
          <Ionicons name="settings-outline" size={20} color={colors.mutedForeground} />
        </Pressable>
      </Panel>

      <View style={styles.stats}>
        <StatTile label="Points" value={points} icon="trophy-outline" accent />
        <StatTile label="Reports" value={mine.length} icon="pin-outline" />
        <StatTile label="Confirmed" value={mine.reduce((sum, report) => sum + report.upvotes, 0)} icon="checkmark-done-outline" />
      </View>

      <Panel style={styles.badgePanel}>
        <View style={styles.sectionHead}>
          <View>
            <AppText size={16} weight="bold">Your badges</AppText>
            <AppText size={11} tone="muted" style={styles.smallSub}>Earn one each time your impact grows.</AppText>
          </View>
          <Ionicons name="ribbon-outline" size={22} color={colors.accent} />
        </View>
        {badges.length ? (
          <View style={styles.badges}>
            {badges.map((badge) => (
              <View key={badge} style={[styles.badge, { borderColor: colors.border }]}>
                <Ionicons name="shield-checkmark-outline" size={16} color={colors.accent} />
                <AppText size={11} weight="semibold">{badge}</AppText>
              </View>
            ))}
          </View>
        ) : (
          <View style={styles.badgeEmpty}>
            <Ionicons name="lock-closed-outline" size={15} color={colors.mutedForeground} />
            <AppText size={12} tone="muted">Your first report unlocks a badge.</AppText>
          </View>
        )}
      </Panel>

      <Panel style={styles.leaderPanel}>
        <View style={styles.sectionHead}>
          <View>
            <AppText size={16} weight="bold">Top reporters</AppText>
            <AppText size={11} tone="muted" style={styles.smallSub}>Most reports in the shared feed</AppText>
          </View>
          <Ionicons name="podium-outline" size={22} color={colors.accent} />
        </View>
        {leaderboard.length ? leaderboard.map((person, index) => (
          <View key={person.id} style={[styles.leaderRow, index < leaderboard.length - 1 && { borderBottomColor: colors.border }]}>
            <View style={[styles.rank, { backgroundColor: index === 0 ? '#3B2B13' : colors.secondary }]}>
              <AppText size={11} weight="bold" tone={index === 0 ? 'warning' : 'muted'}>{index + 1}</AppText>
            </View>
            <AppText size={13} weight="medium" style={styles.identityCopy}>{person.label}</AppText>
            <AppText size={12} tone="muted">{person.count} reports</AppText>
          </View>
        )) : (
          <AppText size={12} tone="muted">The leaderboard appears when community reports arrive.</AppText>
        )}
      </Panel>

      <Panel style={styles.menu}>
        <MenuItem icon="document-text-outline" title="My reports" subtitle="Track every report and repair status" onPress={() => router.push('/my-reports')} />
        <MenuItem icon="settings-outline" title="Settings" subtitle="Sensitivity, units and privacy" onPress={() => router.push('/settings')} />
        {admin ? <MenuItem icon="construct-outline" title="City admin" subtitle="Review reports and export data" onPress={() => router.push('/admin')} /> : null}
      </Panel>

      {!user ? (
        <AppButton title={guestMode ? 'Sign in to sync your activity' : 'Log in or create an account'} icon="log-in-outline" onPress={() => router.push('/(auth)/login')} />
      ) : null}
    </AppScreen>
  );
}

function MenuItem({
  icon,
  title,
  subtitle,
  onPress,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={[styles.menuItem, { borderBottomColor: colors.border }]}>
      <Ionicons name={icon} size={19} color={colors.accent} />
      <View style={styles.identityCopy}>
        <AppText size={13} weight="semibold">{title}</AppText>
        <AppText size={11} tone="muted">{subtitle}</AppText>
      </View>
      <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 14, paddingBottom: 28, gap: 15 },
  identity: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: { width: 56, height: 56, borderRadius: 19, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  identityCopy: { flex: 1, gap: 4 },
  stats: { flexDirection: 'row', gap: 8 },
  badgePanel: { gap: 14 },
  sectionHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  smallSub: { marginTop: 4 },
  badges: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  badge: { minHeight: 34, borderWidth: 1, borderRadius: 100, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 7 },
  badgeEmpty: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  leaderPanel: { gap: 13 },
  leaderRow: { minHeight: 42, flexDirection: 'row', alignItems: 'center', gap: 10, borderBottomWidth: StyleSheet.hairlineWidth, paddingBottom: 7 },
  rank: { width: 26, height: 26, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  menu: { paddingHorizontal: 14, paddingVertical: 1, gap: 0 },
  menuItem: { minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: StyleSheet.hairlineWidth },
});
