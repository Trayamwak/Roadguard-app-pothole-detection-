import type { PhotoAssessment, Severity } from '@/types';
import { File, Paths } from 'expo-file-system';
import { auth } from '@/lib/firebase';

const rank: Record<Severity, number> = {
  Low: 1,
  Medium: 2,
  High: 3,
  Critical: 4,
};

function fromRank(value: number): Severity {
  if (value < 1.5) return 'Low';
  if (value < 2.5) return 'Medium';
  if (value < 3.5) return 'High';
  return 'Critical';
}

/**
 * Combines the photo model's result with the optional vehicle-motion spike.
 * The image remains the primary signal (75%); motion contributes up to 25%.
 * A sensor-only report is never presented as an AI photo classification.
 */
export function combineSeverity(
  photo: PhotoAssessment | null,
  spikeMagnitude?: number | null,
): PhotoAssessment {
  if (!photo && spikeMagnitude == null) {
    return {
      severity: 'Low',
      confidence: 0,
      reason: 'No model result is available yet. Choose a severity or connect the analysis service.',
    };
  }

  const motionRank =
    spikeMagnitude == null
      ? null
      : 1 + Math.max(0, Math.min(3, (spikeMagnitude - 0.8) / 0.8));

  if (!photo) {
    return {
      severity: fromRank(motionRank ?? 1),
      confidence: 35,
      reason: 'Estimated from the confirmed motion spike; a photo assessment was not available.',
    };
  }

  const combinedRank =
    motionRank == null
      ? rank[photo.severity]
      : rank[photo.severity] * 0.75 + motionRank * 0.25;
  const motionNote =
    motionRank == null
      ? ''
      : ` Motion signal: ${spikeMagnitude?.toFixed(1)} g.`;

  return {
    severity: fromRank(combinedRank),
    confidence: Math.max(0, Math.min(100, Math.round(photo.confidence))),
    reason: `${photo.reason}${motionNote}`,
  };
}

export async function assessPhoto(photoUri: string): Promise<PhotoAssessment | null> {
  const endpoint = process.env.EXPO_PUBLIC_SEVERITY_API_URL;
  if (!endpoint) return null;

  const body = new FormData();
  body.append(
    'photo',
    {
      uri: photoUri,
      name: 'pothole-report.jpg',
      type: 'image/jpeg',
    } as unknown as Blob,
  );
  const token = await auth?.currentUser?.getIdToken();
  if (!token) throw new Error('Sign in to use the authenticated photo analysis service.');

  const response = await fetch(`${endpoint.replace(/\/$/, '')}/analyze`, {
    method: 'POST',
    body,
    headers: { Accept: 'application/json', Authorization: `Bearer ${token}` },
  });
  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || `Analysis service returned ${response.status}.`);
  }
  const result = (await response.json()) as PhotoAssessment;
  if (!['Low', 'Medium', 'High', 'Critical'].includes(result.severity)) {
    throw new Error('The analysis service returned an unsupported severity.');
  }
  return result;
}

export async function blurSensitivePhoto(photoUri: string): Promise<string | null> {
  const endpoint = process.env.EXPO_PUBLIC_SEVERITY_API_URL;
  if (!endpoint) return null;
  const token = await auth?.currentUser?.getIdToken();
  if (!token) throw new Error('Sign in to use automatic face and plate blurring.');

  const body = new FormData();
  body.append(
    'photo',
    {
      uri: photoUri,
      name: 'pothole-report.jpg',
      type: 'image/jpeg',
    } as unknown as Blob,
  );
  const response = await fetch(`${endpoint.replace(/\/$/, '')}/privacy-blur`, {
    method: 'POST',
    body,
    headers: { Authorization: `Bearer ${token}`, Accept: 'image/jpeg' },
  });
  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || `Privacy service returned ${response.status}.`);
  }
  const image = new File(Paths.cache, `privacy-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.jpg`);
  image.write(new Uint8Array(await response.arrayBuffer()));
  return image.uri;
}
