export type Severity = 'Low' | 'Medium' | 'High' | 'Critical';
export type ReportSource = 'sensor' | 'camera' | 'ai_live' | 'ai_upload';
export type ReportStatus = 'open' | 'fixed';

export interface PotholeReport {
  id: string;
  userId: string;
  authorLabel: string;
  lat: number;
  lng: number;
  severity: Severity;
  confidence: number;
  reason: string;
  imageUrl: string | null;
  source: ReportSource;
  status: ReportStatus;
  upvotes: number;
  createdAt: number;
  note: string;
  pendingSync?: boolean;
  spikeMagnitude?: number | null;
  localImageUri?: string | null;
  address?: string | null;
}

export interface PotholeDetection {
  bbox: [number, number, number, number];
  confidence: number;
  severity: Severity;
  area_percent: number;
}

export interface DetectionResult {
  potholes: PotholeDetection[];
  overall_severity: Severity | 'None';
}

export interface ScanRecord {
  id: string;
  source: 'ai_live' | 'ai_upload';
  createdAt: number;
  photoUri: string | null;
  potholes: PotholeDetection[];
  overallSeverity: Severity | 'None';
  address: string | null;
  lat: number | null;
  lng: number | null;
  reportId: string | null;
  status: 'saved' | 'discarded' | 'pending';
  note: string;
}

export interface PhotoAssessment {
  severity: Severity;
  confidence: number;
  reason: string;
}

export interface AppSettings {
  sensitivity: number;
  useMiles: boolean;
  notificationsEnabled: boolean;
  anonymousReports: boolean;
  driveMode: boolean;
  autoSaveScans: boolean;
}

export const DEFAULT_SETTINGS: AppSettings = {
  sensitivity: 1.6,
  useMiles: false,
  notificationsEnabled: false,
  anonymousReports: false,
  driveMode: false,
  autoSaveScans: false,
};

export const SEVERITIES: Severity[] = ['Low', 'Medium', 'High', 'Critical'];
