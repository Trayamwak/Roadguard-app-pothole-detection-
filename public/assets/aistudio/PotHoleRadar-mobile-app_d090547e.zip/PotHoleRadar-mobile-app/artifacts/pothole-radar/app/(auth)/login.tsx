import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { AppButton, AppText, Field, Panel, SmallIconButton } from '@/components/AppUI';
import { auth, firebaseConfigured, getFirebaseSetupMessage } from '@/lib/firebase';
import { useApp } from '@/providers/AppProvider';
import { useColors } from '@/hooks/useColors';

export default function LoginScreen() {
  const colors = useColors();
  const { setGuestMode } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    setError('');
    if (!firebaseConfigured || !auth) {
      setError(getFirebaseSetupMessage());
      return;
    }
    if (!email.trim() || !password) {
      setError('Enter your email and password to continue.');
      return;
    }
    setBusy(true);
    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
      setGuestMode(false);
      router.replace('/(tabs)');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not sign in.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={styles.content}
      bottomOffset={70}
      keyboardShouldPersistTaps="handled"
    >
      <SmallIconButton icon="arrow-back" accessibilityLabel="Back" onPress={() => router.back()} />
      <View style={styles.header}>
        <View style={[styles.mark, { backgroundColor: '#291311' }]}>
          <AppText size={24} tone="accent" weight="bold">P</AppText>
        </View>
        <AppText size={30} weight="bold">Welcome back</AppText>
        <AppText size={14} tone="muted">Sign in to see your reports and community map.</AppText>
      </View>
      <Panel style={styles.form}>
        <Field label="Email address" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" autoComplete="email" />
        <Field label="Password" value={password} onChangeText={setPassword} placeholder="Your password" secureTextEntry autoComplete="password" />
        {error ? <AppText size={12} tone="primary" style={styles.error}>{error}</AppText> : null}
        <AppButton title="Log in" icon="log-in-outline" loading={busy} onPress={submit} testID="login-submit" />
        <Pressable accessibilityRole="button" onPress={() => router.push('/(auth)/forgot-password')} style={styles.linkButton}>
          <AppText size={13} tone="accent" weight="semibold">Forgot password?</AppText>
        </Pressable>
      </Panel>
      <View style={styles.footer}>
        <AppText size={13} tone="muted">New to PotHoleRadar?</AppText>
        <Pressable accessibilityRole="button" onPress={() => router.replace('/(auth)/signup')}>
          <AppText size={13} tone="accent" weight="semibold"> Create account</AppText>
        </Pressable>
      </View>
      {!firebaseConfigured ? (
        <Panel style={{ borderColor: colors.border }}>
          <AppText size={12} tone="muted" style={{ lineHeight: 18 }}>{getFirebaseSetupMessage()}</AppText>
        </Panel>
      ) : null}
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 22, paddingTop: 20, paddingBottom: 40, gap: 22, maxWidth: 520, width: '100%', alignSelf: 'center' },
  header: { gap: 8, marginTop: 4 },
  mark: { width: 52, height: 52, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  form: { gap: 18 },
  error: { lineHeight: 18 },
  linkButton: { alignSelf: 'center', paddingVertical: 4 },
  footer: { flexDirection: 'row', justifyContent: 'center', gap: 2 },
});
