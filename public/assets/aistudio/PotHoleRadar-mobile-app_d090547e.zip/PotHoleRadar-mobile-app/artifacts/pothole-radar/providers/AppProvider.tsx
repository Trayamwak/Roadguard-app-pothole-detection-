import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import * as Network from 'expo-network';
import { auth, firebaseConfigured } from '@/lib/firebase';
import { confirmReport, createReport, subscribeReports, syncQueuedReports } from '@/lib/reports';
import { getQueuedReports, getSettings, saveQueuedReport, saveSettings } from '@/lib/storage';
import type { AppSettings, PotholeReport } from '@/types';
import { DEFAULT_SETTINGS } from '@/types';

interface AppContextValue {
  user: User | null;
  guestMode: boolean;
  setGuestMode: (value: boolean) => void;
  firebaseReady: boolean;
  reports: PotholeReport[];
  settings: AppSettings;
  updateSettings: (settings: AppSettings) => Promise<void>;
  isLoadingReports: boolean;
  reportError: string | null;
  addReport: (report: PotholeReport) => Promise<{ merged: boolean; synced: boolean; reportId: string }>;
  confirmPothole: (reportId: string) => Promise<void>;
  reloadReports: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [guestMode, setGuestMode] = useState(false);
  const [remoteReports, setRemoteReports] = useState<PotholeReport[]>([]);
  const [queuedReports, setQueuedReports] = useState<PotholeReport[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isLoadingReports, setIsLoadingReports] = useState(true);
  const [reportError, setReportError] = useState<string | null>(null);

  const reloadReports = useCallback(async () => {
    setQueuedReports(await getQueuedReports());
  }, []);

  useEffect(() => {
    getSettings().then(setSettings).catch(() => setSettings(DEFAULT_SETTINGS));
    reloadReports().catch(() => setQueuedReports([]));
    if (!auth) {
      setIsLoadingReports(false);
      return;
    }
    return onAuthStateChanged(auth, setUser);
  }, [reloadReports]);

  useEffect(() => {
    const unsubscribe = subscribeReports(
      setRemoteReports,
      (error) => setReportError(error.message),
    );
    if (firebaseConfigured) setReportError(null);
    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    let active = true;
    const sync = async () => {
      if (!user || !firebaseConfigured) return;
      const network = await Network.getNetworkStateAsync().catch(() => null);
      if (!network?.isConnected) return;
      const queue = await getQueuedReports();
      await syncQueuedReports(queue);
      if (active) await reloadReports();
    };
    sync().catch(() => undefined);
    const subscription = Network.addNetworkStateListener((state) => {
      if (state.isConnected) sync().catch(() => undefined);
    });
    return () => {
      active = false;
      subscription.remove();
    };
  }, [user, reloadReports]);

  useEffect(() => {
    setIsLoadingReports(false);
  }, [remoteReports, queuedReports]);

  const reports = useMemo(() => {
    const byId = new Map(remoteReports.map((report) => [report.id, report]));
    for (const report of queuedReports) {
      if (!byId.has(report.id)) byId.set(report.id, report);
    }
    return [...byId.values()].sort((a, b) => b.createdAt - a.createdAt);
  }, [remoteReports, queuedReports]);

  const updateSettings = useCallback(async (next: AppSettings) => {
    setSettings(next);
    await saveSettings(next);
  }, []);

  const addReport = useCallback(
    async (report: PotholeReport) => {
      await saveQueuedReport({ ...report, pendingSync: true });
      await reloadReports();
      try {
        const result = await createReport({ ...report, pendingSync: true });
        await reloadReports();
        return { merged: result.merged, synced: result.synced, reportId: result.report.id };
      } catch {
        await reloadReports();
        return { merged: false, synced: false, reportId: report.id };
      }
    },
    [reloadReports],
  );

  const confirmPothole = useCallback(
    async (reportId: string) => {
      const pending = queuedReports.find((report) => report.id === reportId);
      if (pending) {
        const updated = { ...pending, upvotes: pending.upvotes + 1 };
        await saveQueuedReport(updated);
        await reloadReports();
        return;
      }
      await confirmReport(reportId);
    },
    [queuedReports, reloadReports],
  );

  const value = useMemo(
    () => ({
      user,
      guestMode,
      setGuestMode,
      firebaseReady: firebaseConfigured,
      reports,
      settings,
      updateSettings,
      isLoadingReports,
      reportError,
      addReport,
      confirmPothole,
      reloadReports,
    }),
    [
      user,
      guestMode,
      reports,
      settings,
      updateSettings,
      isLoadingReports,
      reportError,
      addReport,
      confirmPothole,
      reloadReports,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const value = useContext(AppContext);
  if (!value) throw new Error('useApp must be used inside AppProvider.');
  return value;
}
