import { useEffect, useRef, useState } from 'react';
import { Accelerometer } from 'expo-sensors';
import * as Location from 'expo-location';
import { Platform } from 'react-native';

const SPEED_FLOOR_KMH = 10;
const DEBOUNCE_MS = 3000;

export function usePotholeDetection(
  enabled: boolean,
  threshold: number,
  onPossiblePothole: (magnitude: number) => void,
) {
  const callback = useRef(onPossiblePothole);
  const lastSpikeAt = useRef(0);
  const lowPassZ = useRef(0);
  const [speedKmh, setSpeedKmh] = useState(0);
  const [sensorAvailable, setSensorAvailable] = useState(false);

  useEffect(() => {
    callback.current = onPossiblePothole;
  }, [onPossiblePothole]);

  useEffect(() => {
    if (!enabled || Platform.OS === 'web') {
      setSensorAvailable(false);
      setSpeedKmh(0);
      return;
    }

    let mounted = true;
    let locationSubscription: Location.LocationSubscription | null = null;
    let sensorSubscription: ReturnType<typeof Accelerometer.addListener> | null = null;

    const start = async () => {
      try {
        const locationPermission = await Location.requestForegroundPermissionsAsync();
        if (!locationPermission.granted || !mounted) return;

        const available = await Accelerometer.isAvailableAsync();
        if (!available || !mounted) return;
        setSensorAvailable(true);
        Accelerometer.setUpdateInterval(20);

        sensorSubscription = Accelerometer.addListener(({ z }) => {
          const filtered = lowPassZ.current * 0.8 + z * 0.2;
          const spike = Math.abs(z - lowPassZ.current);
          lowPassZ.current = filtered;
          if (
            speedKmh >= SPEED_FLOOR_KMH &&
            spike >= threshold &&
            Date.now() - lastSpikeAt.current >= DEBOUNCE_MS
          ) {
            lastSpikeAt.current = Date.now();
            callback.current(spike);
          }
        });

        locationSubscription = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.Balanced,
            timeInterval: 1000,
            distanceInterval: 0,
          },
          (location) => {
            const speed = location.coords.speed ?? 0;
            setSpeedKmh(Math.max(0, speed * 3.6));
          },
        );
      } catch {
        setSensorAvailable(false);
      }
    };

    start();
    return () => {
      mounted = false;
      sensorSubscription?.remove();
      locationSubscription?.remove();
      Accelerometer.removeAllListeners();
    };
  }, [enabled, threshold, speedKmh >= SPEED_FLOOR_KMH]);

  return { speedKmh, sensorAvailable };
}
