# PotHoleRadar

A dark, high-contrast Expo app for Android and iOS. It supports Firebase email/password accounts, AI live-camera and gallery scans, foreground GPS, accelerometer Drive Mode, pothole-aware route comparison, a shared map and feed, offline report queuing, confirmations, reporter badges, status tracking, push-notification hooks, and an admin CSV export screen.

## Project structure

```text
artifacts/pothole-radar/
├── app/                     # Expo Router screens and tabs
├── components/AppUI.tsx     # Shared mobile controls and report rows
├── constants/colors.ts      # PotHoleRadar dark theme
├── hooks/                   # Accelerometer and pothole-proximity detection
├── lib/                     # Firebase, report sync, severity, settings, push
├── providers/               # Auth, reports, local queue and settings
├── types/                   # Shared TypeScript model
├── firestore.rules          # Public reads; owner writes; admin status changes
├── storage.rules            # Authenticated image upload policy
├── firebase/functions/      # Push notification trigger for fixed reports
└── ai-service/              # Optional FastAPI + YOLOv8 severity service
```

## Run the mobile app

1. From the project root, install dependencies:

   ```bash
   pnpm install
   ```

2. Copy `.env.example` to `.env` inside this artifact and enter the Firebase **client** configuration from Firebase Console → Project settings → Your apps. Add the API service URL and restricted Maps SDK key when those services are configured. Do not place a Firebase service-account key or Google server key in this file.
3. In Firebase Authentication, enable Email/Password sign-in. Create Firestore and Storage, then publish `firestore.rules` and `storage.rules`.
4. Start the managed Expo workflow in Replit, or run it through the workspace workflow command:

   ```bash
   pnpm --filter @workspace/pothole-radar run dev
   ```

5. Use the mobile preview QR code with Expo Go on iOS or Android. Camera, sensors, location, notifications, maps, and file-sharing require a native device; the browser preview supports image-flow layout but not a live native camera or route map.

### Google Maps and safer routes

1. In Google Cloud Console, enable **Maps SDK for Android**, **Maps SDK for iOS**, and **Directions API** for the project.
2. Create a mobile Maps SDK key and restrict it to this app’s Android package + signing certificate SHA-1 and iOS bundle identifier. Put it in `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY`. `app.config.js` injects it into the native Expo config; do not commit a real key.
3. Create a separate server key restricted to the Directions API and the server’s IP/network. Set `GOOGLE_MAPS_SERVER_API_KEY` in the FastAPI hosting environment’s secret manager. Never put this key in the Expo app or a `EXPO_PUBLIC_*` variable.
4. Rebuild the native app after changing Maps SDK configuration. For local device testing, set `EXPO_PUBLIC_SEVERITY_API_URL` to an HTTPS endpoint or a server address reachable from the phone; `localhost` on the phone is the phone itself.

The native report map uses Google Maps when the key is configured. Safe Route sends the user’s origin and destination to the authenticated FastAPI `/safe-route` endpoint, which requests Google driving alternatives and ranks them using nearby open High/Critical reports. It shows known warnings on the selected route and opens Google Maps for turn-by-turn navigation. API usage may incur Google Cloud charges; set quotas and billing alerts.

### Firebase configuration

All `EXPO_PUBLIC_FIREBASE_*` values are client-side Firebase app identifiers/configuration, not service-account credentials. The app deliberately stays in local-only mode until all six are present. Reports created without an account or network are held in AsyncStorage and are marked “On device” until sync succeeds.

### Severity service

The mobile app sends compressed images to `EXPO_PUBLIC_SEVERITY_API_URL/detect`. The separate `ai-service` folder contains a FastAPI service that verifies Firebase ID tokens, checks image size and blur, and runs a YOLO model. It returns normalized bounding boxes, per-box confidence, severity, area percentage, and overall severity. Severity combines box area, confidence, and a weak lower-frame perspective cue; it is an estimate, not a road-engineering assessment. The `/privacy-blur` endpoint attempts face and plate blurring. Blurring is best effort, so the app requires a human review before manually saving a report.

An AI image is sent to the configured detection service even if the user discards it; it is not stored by this service by default. The image is uploaded to Firebase Storage only when a report is saved. Auto-save is allowed only when GPS is attached and the blur service returned a processed photo; otherwise the user must review and save manually. AI scans and route requests require a signed-in Firebase user.

For a separately hosted service:

```bash
cd artifacts/pothole-radar/ai-service
pip install -r requirements.txt
export FIREBASE_PROJECT_ID=your-firebase-project-id
export GOOGLE_APPLICATION_CREDENTIALS=/secure/path/to/firebase-admin.json
export YOLO_WEIGHTS=/secure/path/to/pothole-yolov8.pt
export GOOGLE_MAPS_SERVER_API_KEY=your-restricted-server-key
# Allow the web preview origin only if using browser-based image uploads.
export CORS_ORIGINS=https://your-web-preview-origin.example
uvicorn main:app --host 0.0.0.0 --port 8000
```

`/health` checks whether model weights loaded. No model weights or dataset are included. Train a custom model in Colab with a properly licensed, labeled pothole dataset, for example:

```python
from ultralytics import YOLO

model = YOLO("yolov8n.pt")
model.train(data="/content/potholes/data.yaml", imgsz=640, epochs=100)
# Copy runs/detect/train/weights/best.pt to the protected AI-service host.
```

Set `YOLO_WEIGHTS` to the deployed `best.pt` path and `YOLO_CLASS_NAMES` to the pothole class label used by the dataset if it differs from `pothole`. Keep model weights and Firebase Admin credentials outside source control. The in-process rate limiter is a starter guard; use a shared limiter and authenticated deployment gateway before production traffic.

### Device and service checks

```bash
pnpm --filter @workspace/pothole-radar run typecheck
python -m py_compile artifacts/pothole-radar/ai-service/main.py
```

On a signed-in Android and iOS device, test camera and photo-library permissions, upload a clear and a blurry image, check annotated boxes and severity, save and discard, and confirm the saved report appears in history and the map. Test auto-save with GPS and privacy blur enabled, then verify the manual-review path when blur is unavailable. Disable the network before saving to check the local queue, reconnect and confirm sync, and submit a second scan within 10 m to check duplicate confirmation. For routing, enable the three Google APIs above, verify route markers and the Google Maps handoff, and simulate a location within 200 m of a High/Critical open report to check the banner and haptic alert.

### Push notifications and admin access

- The user opts into repair alerts in Settings; the app registers an Expo push token in `users/{uid}/pushTokens`.
- Deploy `firebase/functions/index.js` as a Firebase Cloud Function to send a push after a report changes to `fixed`.
- A trusted Firebase Admin SDK account must grant an administrator the custom claim `admin: true`. The Firestore rules reject repair-status changes from ordinary users.
- The leaderboard is derived from public report authorship counts; points are calculated from a reporter’s own reports (25 each).

## Android and iOS builds

The project includes Expo native permission strings and configuration for camera, location, motion, notifications, photo picking, map rendering, and CSV sharing. Replit supports iOS and Android builds/previews and guided iOS App Store submission. EAS CLI builds and Google Play Store publishing are not supported by the Replit publishing flow; use an external Android build provider for Play Store packaging. Native builds need the Maps SDK key described above and an Expo project ID for push tokens.

## Safety, privacy, and known limits

- Drive Mode checks accelerometer samples at about 50 Hz and foreground GPS speed. It runs only while the app is open; it is not background trip tracking.
- A sensor spike must exceed the configured threshold, occur above 10 km/h, and be at least three seconds after the prior detection.
- AI scans send a compressed frame/photo to the configured service for processing, even if the user discards the result. Report photos are stored only after Save. Face/plate blur is best effort and must not be treated as a privacy guarantee.
- Duplicate reports within ten metres are matched against the latest 250 reports and are merged by adding a confirmation. For high-volume, race-free deduplication, move this check to a trusted server transaction.
- Push delivery requires a deployed Firebase Function and a native app build with Expo project ID. The workspace preview cannot deliver remote push notifications.
