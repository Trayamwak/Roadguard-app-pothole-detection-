import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AppSettings, PotholeReport, ScanRecord } from '@/types';
import { DEFAULT_SETTINGS } from '@/types';

const QUEUE_KEY = 'potholedar:report-queue:v1';
const SETTINGS_KEY = 'potholedar:settings:v1';
const SCAN_HISTORY_KEY = 'potholedar:scan-history:v1';

export async function getQueuedReports(): Promise<PotholeReport[]> {
  const value = await AsyncStorage.getItem(QUEUE_KEY);
  if (!value) return [];
  try {
    return JSON.parse(value) as PotholeReport[];
  } catch {
    await AsyncStorage.removeItem(QUEUE_KEY);
    return [];
  }
}

export async function saveQueuedReport(report: PotholeReport) {
  const queue = await getQueuedReports();
  const existing = queue.find((item) => item.id === report.id);
  const next = existing
    ? queue.map((item) => (item.id === report.id ? report : item))
    : [report, ...queue];
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(next));
}

export async function removeQueuedReport(id: string) {
  const next = (await getQueuedReports()).filter((report) => report.id !== id);
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(next));
}

export async function getSettings(): Promise<AppSettings> {
  const value = await AsyncStorage.getItem(SETTINGS_KEY);
  if (!value) return DEFAULT_SETTINGS;
  try {
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(value) as Partial<AppSettings>) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export async function saveSettings(settings: AppSettings) {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export async function getScanHistory(): Promise<ScanRecord[]> {
  const value = await AsyncStorage.getItem(SCAN_HISTORY_KEY);
  if (!value) return [];
  try {
    return (JSON.parse(value) as ScanRecord[]).slice(0, 100);
  } catch {
    await AsyncStorage.removeItem(SCAN_HISTORY_KEY);
    return [];
  }
}

export async function saveScanRecord(record: ScanRecord) {
  const next = (await getScanHistory()).filter((item) => item.id !== record.id);
  await AsyncStorage.setItem(SCAN_HISTORY_KEY, JSON.stringify([record, ...next].slice(0, 100)));
}

export async function updateScanRecord(id: string, changes: Partial<ScanRecord>) {
  const history = await getScanHistory();
  const current = history.find((item) => item.id === id);
  if (!current) return;
  await saveScanRecord({ ...current, ...changes });
}
