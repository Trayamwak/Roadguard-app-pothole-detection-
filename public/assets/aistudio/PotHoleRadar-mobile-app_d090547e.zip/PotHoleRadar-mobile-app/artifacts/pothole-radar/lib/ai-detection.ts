import { manipulateAsync, SaveFormat } from 'expo-image-manipulator';
import { auth } from '@/lib/firebase';
import type { DetectionResult, PotholeDetection, Severity } from '@/types';

const severities: Severity[] = ['Low', 'Medium', 'High', 'Critical'];

export async function compressDetectionImage(uri: string): Promise<string> {
  const image = await manipulateAsync(
    uri,
    [{ resize: { width: 1280 } }],
    { compress: 0.62, format: SaveFormat.JPEG },
  );
  return image.uri;
}

export async function detectPotholes(uri: string): Promise<DetectionResult> {
  const endpoint = process.env.EXPO_PUBLIC_SEVERITY_API_URL?.replace(/\/$/, '');
  if (!endpoint) throw new Error('Connect the FastAPI service in EXPO_PUBLIC_SEVERITY_API_URL to use AI Scan.');
  const token = await auth?.currentUser?.getIdToken();
  if (!token) throw new Error('Log in to use the authenticated AI scanning service.');

  const body = new FormData();
  body.append(
    'photo',
    { uri, name: 'pothole-scan.jpg', type: 'image/jpeg' } as unknown as Blob,
  );
  let response: Response;
  try {
    response = await fetch(`${endpoint}/detect`, {
      method: 'POST',
      body,
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
    });
  } catch {
    throw new Error('Could not reach the scan service. Check your internet connection and try again.');
  }

  const payload = await response.json().catch(() => ({})) as {
    detail?: string;
    potholes?: PotholeDetection[];
    overall_severity?: string;
  };
  if (!response.ok) {
    throw new Error(payload.detail || `Scan service returned ${response.status}.`);
  }
  if (!Array.isArray(payload.potholes)) {
    throw new Error('The scan service returned an invalid detection result.');
  }
  const potholes = payload.potholes.filter(
    (item) =>
      item &&
      Array.isArray(item.bbox) &&
      item.bbox.length === 4 &&
      severities.includes(item.severity) &&
      Number.isFinite(item.confidence),
  );
  const overallSeverity = payload.overall_severity;
  if (overallSeverity !== 'None' && !severities.includes(overallSeverity as Severity)) {
    throw new Error('The scan service returned an unsupported severity.');
  }
  return {
    potholes,
    overall_severity: overallSeverity as DetectionResult['overall_severity'],
  };
}
