import React, { useCallback, useState } from 'react';
import { Pressable, Share, StyleSheet, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { AppButton, AppScreen, AppText, Panel, PageTitle, Pill, SeverityBadge, SmallIconButton } from '@/components/AppUI';
import { SkeletonReportCard } from '@/components/SkeletonLoader';
import { getScanHistory } from '@/lib/storage';
import { useColors } from '@/hooks/useColors';
import type { ScanRecord, Severity } from '@/types';

const severityFilters = ['All', 'Low', 'Medium', 'High', 'Critical', 'None'] as const;
const dateFilters = ['7 days', '30 days', 'All'] as const;

export default function ScanHistoryScreen() {
  const colors = useColors();
  const [records, setRecords] = useState<ScanRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [severity, setSeverity] = useState<(typeof severityFilters)[number]>('All');
  const [dateWindow, setDateWindow] = useState<(typeof dateFilters)[number]>('30 days');

  useFocusEffect(useCallback(() => {
    let active = true;
    setLoading(true);
    getScanHistory()
      .then((history) => { if (active) setRecords(history); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []));

  const filtered = records.filter((record) => {
    const cutoff =
      dateWindow === '7 days'
        ? Date.now() - 7 * 86400000
        : dateWindow === '30 days'
          ? Date.now() - 30 * 86400000
          : 0;
    const scanSeverity = record.overallSeverity;
    return record.createdAt >= cutoff && (severity === 'All' || scanSeverity === severity);
  });

  const shareScan = async (record: ScanRecord) => {
    const where = record.address || (record.lat != null && record.lng != null ? `${record.lat.toFixed(5)}, ${record.lng.toFixed(5)}` : 'location not attached');
    await Share.share({
      title: 'PotHoleRadar scan',
      message: `${record.overallSeverity === 'None' ? 'No pothole detected' : `${record.overallSeverity} pothole scan`} · ${record.potholes.length} detection(s) · ${where} · ${new Date(record.createdAt).toLocaleString()}`,
    });
  };

  return (
    <AppScreen scroll contentStyle={styles.content}>
      <View style={styles.top}>
        <SmallIconButton icon="chevron-back" accessibilityLabel="Go back" onPress={() => router.back()} />
        <PageTitle eyebrow="Your scans" title="Scan history" subtitle="Recent AI detections and saved reports." />
      </View>
      <View style={styles.filterGroup}>
        <View style={styles.filters}>
          {severityFilters.map((item) => (
            <Pill key={item} title={item} selected={severity === item} onPress={() => setSeverity(item)} />
          ))}
        </View>
        <View style={styles.filters}>
          {dateFilters.map((item) => (
            <Pill key={item} title={item} selected={dateWindow === item} onPress={() => setDateWindow(item)} />
          ))}
        </View>
      </View>

      {loading ? (
        <View style={styles.list}>{[0, 1, 2].map((item) => <SkeletonReportCard key={item} />)}</View>
      ) : filtered.length ? (
        <View style={styles.list}>
          {filtered.map((record, index) => (
            <Animated.View key={record.id} entering={FadeInDown.delay(Math.min(index * 35, 210)).duration(280)}>
              <Panel style={styles.recordCard}>
                <View style={styles.recordHeader}>
                  <View style={styles.sourceIcon}>
                    <Ionicons name={record.source === 'ai_live' ? 'videocam-outline' : 'image-outline'} size={18} color={colors.accent} />
                  </View>
                  <View style={styles.recordCopy}>
                    <View style={styles.titleLine}>
                      {record.overallSeverity === 'None' ? (
                        <AppText size={13} weight="semibold">No pothole detected</AppText>
                      ) : (
                        <SeverityBadge severity={record.overallSeverity as Severity} />
                      )}
                      <AppText size={10} tone={record.status === 'saved' ? 'success' : 'muted'} weight="semibold">
                        {record.status === 'saved' ? 'SAVED' : record.status === 'discarded' ? 'DISCARDED' : 'SCAN'}
                      </AppText>
                    </View>
                    <AppText size={11} tone="muted">
                      {record.source === 'ai_live' ? 'Live camera' : 'Uploaded image'} · {record.potholes.length} detection(s)
                    </AppText>
                    <AppText size={10} tone="muted">
                      {record.address || 'No location'} · {new Date(record.createdAt).toLocaleString()}
                    </AppText>
                  </View>
                  <Pressable accessibilityRole="button" accessibilityLabel="Share scan" onPress={() => void shareScan(record)} style={styles.shareButton}>
                    <Ionicons name="share-social-outline" size={18} color={colors.accent} />
                  </Pressable>
                </View>
                {record.status === 'saved' && record.reportId ? (
                  <Pressable accessibilityRole="button" onPress={() => router.push({ pathname: '/report/[id]', params: { id: record.reportId! } })} style={styles.openReport}>
                    <AppText size={11} tone="accent" weight="semibold">Open saved report</AppText>
                    <Ionicons name="chevron-forward" size={14} color={colors.accent} />
                  </Pressable>
                ) : null}
              </Panel>
            </Animated.View>
          ))}
        </View>
      ) : (
        <Panel style={styles.empty}>
          <View style={styles.emptyIcon}><Ionicons name="scan-outline" size={24} color={colors.accent} /></View>
          <AppText size={14} weight="semibold">No scans in this filter</AppText>
          <AppText size={11} tone="muted">Your AI scan results will appear here.</AppText>
          <AppButton title="Start an AI scan" icon="scan-outline" onPress={() => router.push('/ai-scan')} />
        </Panel>
      )}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 12, paddingBottom: 35, gap: 15 },
  top: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  filterGroup: { gap: 8 },
  filters: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  list: { gap: 9 },
  recordCard: { gap: 10 },
  recordHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  sourceIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: '#2A1A13' },
  recordCopy: { flex: 1, gap: 5 },
  titleLine: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 7 },
  shareButton: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  openReport: { minHeight: 30, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#353535', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 7 },
  empty: { minHeight: 240, alignItems: 'center', justifyContent: 'center', gap: 10, padding: 20 },
  emptyIcon: { width: 52, height: 52, borderRadius: 17, alignItems: 'center', justifyContent: 'center', backgroundColor: '#2A1A13' },
});
