import React, { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { AppButton, AppScreen, AppText, EmptyState, PageTitle, ReportRow, SmallIconButton } from '@/components/AppUI';
import { useApp } from '@/providers/AppProvider';

export default function MyReportsScreen() {
  const { reports, user, guestMode } = useApp();
  const ownId = user?.uid ?? (guestMode ? 'guest' : '');
  const mine = useMemo(() => reports.filter((report) => report.userId === ownId), [ownId, reports]);
  return (
    <AppScreen scroll contentStyle={styles.content}>
      <View style={styles.top}><SmallIconButton icon="close" accessibilityLabel="Close my reports" onPress={() => router.back()} /></View>
      <PageTitle eyebrow="Your activity" title="My reports" subtitle={`${mine.length} ${mine.length === 1 ? 'report' : 'reports'} submitted`} />
      {mine.length ? (
        <View style={styles.list}>
          {mine.map((report) => (
            <ReportRow key={report.id} report={report} onPress={() => router.push({ pathname: '/report/[id]', params: { id: report.id } })} />
          ))}
        </View>
      ) : (
        <EmptyState
          icon="pin-outline"
          title="No reports yet"
          description="When you report a road issue, it will appear here with its status and community confirmations."
          action={<AppButton title="Create first report" icon="camera-outline" onPress={() => router.push({ pathname: '/report/new', params: { source: 'camera' } })} />}
        />
      )}
      {!user && !guestMode ? <AppText size={12} tone="muted">Sign in to view your synced reports.</AppText> : null}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 13, gap: 18 },
  top: { flexDirection: 'row' },
  list: { gap: 9 },
});
