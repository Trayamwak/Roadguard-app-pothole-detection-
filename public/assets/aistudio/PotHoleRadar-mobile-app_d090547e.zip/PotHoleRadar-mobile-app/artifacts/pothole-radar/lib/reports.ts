import {
  collection,
  doc,
  increment,
  limit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  getDocs,
  type DocumentData,
  type Unsubscribe,
} from 'firebase/firestore';
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import { auth, db, firebaseConfigured, storage } from '@/lib/firebase';
import { distanceMeters, escapeCsv } from '@/lib/geo';
import { removeQueuedReport, saveQueuedReport } from '@/lib/storage';
import type { PhotoAssessment, PotholeReport } from '@/types';

function fromFirestore(id: string, data: DocumentData): PotholeReport {
  const time = data.createdAt?.toMillis?.() ?? Date.now();
  return {
    id,
    userId: String(data.userId ?? ''),
    authorLabel: String(data.authorLabel ?? 'Road user'),
    lat: Number(data.lat),
    lng: Number(data.lng),
    severity: data.severity,
    confidence: Number(data.confidence ?? 0),
    reason: String(data.reason ?? ''),
    imageUrl: typeof data.imageUrl === 'string' ? data.imageUrl : null,
    source: data.source === 'sensor' || data.source === 'ai_live' || data.source === 'ai_upload'
      ? data.source
      : 'camera',
    status: data.status === 'fixed' ? 'fixed' : 'open',
    upvotes: Number(data.upvotes ?? 0),
    createdAt: time,
    note: String(data.note ?? ''),
    address: typeof data.address === 'string' ? data.address : null,
    spikeMagnitude:
      typeof data.spikeMagnitude === 'number' ? data.spikeMagnitude : null,
  };
}

export function subscribeReports(
  onReports: (reports: PotholeReport[]) => void,
  onError?: (error: Error) => void,
): Unsubscribe {
  if (!db) return () => undefined;
  const reportsQuery = query(
    collection(db, 'reports'),
    orderBy('createdAt', 'desc'),
    limit(250),
  );
  return onSnapshot(
    reportsQuery,
    (snapshot) =>
      onReports(snapshot.docs.map((item) => fromFirestore(item.id, item.data()))),
    (error) => onError?.(error),
  );
}

async function uploadReportPhoto(report: PotholeReport) {
  if (!storage || !report.localImageUri) return null;
  const fileResponse = await fetch(report.localImageUri);
  const blob = await fileResponse.blob();
  const imageRef = ref(storage, `reports/${report.userId}/${report.id}.jpg`);
  const uploaded = await uploadBytes(imageRef, blob, { contentType: 'image/jpeg' });
  return getDownloadURL(uploaded.ref);
}

async function findNearbyReport(report: PotholeReport) {
  if (!db) return null;
  const existing = await getDocs(
    query(collection(db, 'reports'), orderBy('createdAt', 'desc'), limit(250)),
  );
  for (const item of existing.docs) {
    const candidate = fromFirestore(item.id, item.data());
    if (distanceMeters(report, candidate) <= 10) return candidate;
  }
  return null;
}

export async function createReport(report: PotholeReport) {
  if (!firebaseConfigured || !db || !auth?.currentUser) {
    await saveQueuedReport({ ...report, pendingSync: true });
    return { report: { ...report, pendingSync: true }, synced: false, merged: false };
  }

  const duplicate = await findNearbyReport(report);
  if (duplicate) {
    await confirmReport(duplicate.id);
    await removeQueuedReport(report.id);
    return { report: duplicate, synced: true, merged: true };
  }

  const imageUrl = await uploadReportPhoto(report);
  const remoteReport = doc(collection(db, 'reports'));
  const saved: PotholeReport = {
    ...report,
    id: remoteReport.id,
    imageUrl,
    localImageUri: null,
    pendingSync: false,
  };
  await setDoc(remoteReport, {
    userId: auth.currentUser.uid,
    authorLabel: report.authorLabel,
    lat: report.lat,
    lng: report.lng,
    severity: report.severity,
    confidence: report.confidence,
    reason: report.reason,
    imageUrl,
    source: report.source,
    status: 'open',
    upvotes: 0,
    note: report.note.slice(0, 500),
    address: report.address ?? null,
    spikeMagnitude: report.spikeMagnitude ?? null,
    createdAt: serverTimestamp(),
  });
  await removeQueuedReport(report.id);
  return { report: saved, synced: true, merged: false };
}

export async function syncQueuedReports(reports: PotholeReport[]) {
  const completed: string[] = [];
  for (const report of reports) {
    if (!report.pendingSync) continue;
    try {
      const result = await createReport(report);
      if (result.synced) completed.push(report.id);
    } catch {
      // Keep unsent reports on-device. The UI displays the pending sync state.
    }
  }
  return completed;
}

export async function confirmReport(reportId: string) {
  if (!db || !auth?.currentUser) {
    throw new Error('Sign in to confirm a pothole report.');
  }
  const reportRef = doc(db, 'reports', reportId);
  const confirmationRef = doc(
    db,
    'reports',
    reportId,
    'confirmations',
    auth.currentUser.uid,
  );
  await runTransaction(db, async (transaction) => {
    const confirmation = await transaction.get(confirmationRef);
    if (confirmation.exists()) return;
    transaction.set(confirmationRef, { createdAt: serverTimestamp() });
    transaction.update(reportRef, { upvotes: increment(1) });
  });
}

export async function updateReportStatus(reportId: string, status: 'fixed') {
  if (!db || !auth?.currentUser) throw new Error('Sign in to continue.');
  const token = await auth.currentUser.getIdTokenResult();
  if (token.claims.admin !== true) {
    throw new Error('Only an authorized city administrator can mark a report fixed.');
  }
  const reportRef = doc(db, 'reports', reportId);
  await runTransaction(db, async (transaction) => {
    const current = await transaction.get(reportRef);
    if (!current.exists()) throw new Error('This report no longer exists.');
    transaction.update(reportRef, { status });
  });
}

export function reportsToCsv(reports: PotholeReport[]) {
  const headers = [
    'id',
    'userId',
    'latitude',
    'longitude',
    'severity',
    'confidence',
    'source',
    'status',
    'upvotes',
    'createdAt',
    'note',
  ];
  const rows = reports.map((report) =>
    [
      report.id,
      report.userId,
      report.lat,
      report.lng,
      report.severity,
      report.confidence,
      report.source,
      report.status,
      report.upvotes,
      new Date(report.createdAt).toISOString(),
      report.note,
    ]
      .map(escapeCsv)
      .join(','),
  );
  return [headers.join(','), ...rows].join('\n');
}
