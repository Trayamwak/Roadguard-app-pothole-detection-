import React from 'react';
import { Alert, Pressable, StyleSheet, Switch, View } from 'react-native';
import { router } from 'expo-router';
import { signOut } from 'firebase/auth';
import { Ionicons } from '@expo/vector-icons';
import { AppButton, AppScreen, AppText, InfoLine, Panel, PageTitle, SmallIconButton } from '@/components/AppUI';
import { auth } from '@/lib/firebase';
import { setReportStatusNotificationsEnabled } from '@/lib/notifications';
import { useApp } from '@/providers/AppProvider';
import { useColors } from '@/hooks/useColors';

export default function SettingsScreen() {
  const colors = useColors();
  const { user, guestMode, settings, updateSettings, setGuestMode } = useApp();
  const set = (key: keyof typeof settings, value: boolean | number) => {
    updateSettings({ ...settings, [key]: value });
  };
  const toggleNotifications = async (enabled: boolean) => {
    try {
      await setReportStatusNotificationsEnabled(enabled);
      await updateSettings({ ...settings, notificationsEnabled: enabled });
    } catch (error) {
      Alert.alert('Could not update alerts', error instanceof Error ? error.message : 'Try again later.');
    }
  };
  const logOut = async () => {
    try {
      if (settings.notificationsEnabled) {
        await setReportStatusNotificationsEnabled(false).catch(() => undefined);
        await updateSettings({ ...settings, notificationsEnabled: false });
      }
      if (auth?.currentUser) await signOut(auth);
      setGuestMode(false);
      router.replace('/');
    } catch (error) {
      Alert.alert('Could not sign out', error instanceof Error ? error.message : 'Try again.');
    }
  };
  return (
    <AppScreen scroll contentStyle={styles.content}>
      <View style={styles.top}><SmallIconButton icon="close" accessibilityLabel="Close settings" onPress={() => router.back()} /></View>
      <PageTitle eyebrow="Personalize" title="Settings" subtitle="Choose how PotHoleRadar works for you." />

      <Panel style={styles.panel}>
        <AppText size={14} weight="semibold">Drive Mode sensitivity</AppText>
        <AppText size={12} tone="muted">Higher values ignore smaller bumps. Default: 1.6 g.</AppText>
        <View style={styles.sensitivityRow}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Decrease sensitivity"
            onPress={() => set('sensitivity', Math.max(0.8, Math.round((settings.sensitivity - 0.2) * 10) / 10))}
            style={[styles.adjust, { borderColor: colors.border }]}
          >
            <Ionicons name="remove" size={20} color={colors.foreground} />
          </Pressable>
          <View style={styles.sensitivityValue}>
            <AppText size={23} weight="bold">{settings.sensitivity.toFixed(1)} g</AppText>
            <AppText size={10} tone="muted">TRIGGER LEVEL</AppText>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Increase sensitivity"
            onPress={() => set('sensitivity', Math.min(3, Math.round((settings.sensitivity + 0.2) * 10) / 10))}
            style={[styles.adjust, { borderColor: colors.border }]}
          >
            <Ionicons name="add" size={20} color={colors.foreground} />
          </Pressable>
        </View>
      </Panel>

      <Panel style={styles.preferences}>
        <AppText size={14} weight="semibold">Preferences</AppText>
        <Preference
          icon="speedometer-outline"
          title="Distance units"
          subtitle={settings.useMiles ? 'Miles and mph' : 'Kilometres and km/h'}
          value={settings.useMiles}
          onChange={(value) => set('useMiles', value)}
        />
        <Preference
          icon="eye-off-outline"
          title="Anonymous reports"
          subtitle="Hide your name on reports you submit"
          value={settings.anonymousReports}
          onChange={(value) => set('anonymousReports', value)}
        />
        <Preference
          icon="scan-outline"
          title="Auto-save AI scans"
          subtitle="Save detected potholes as reports automatically when location and privacy checks pass"
          value={settings.autoSaveScans}
          onChange={(value) => set('autoSaveScans', value)}
        />
        <Preference
          icon="notifications-outline"
          title="Repair status alerts"
          subtitle="Push notification when an authority marks your report fixed"
          value={settings.notificationsEnabled}
          onChange={toggleNotifications}
        />
      </Panel>

      <Panel style={styles.panel}>
        <AppText size={14} weight="semibold">Privacy and safety</AppText>
        <InfoLine icon="location-outline" title="Location is attached only to submitted reports" subtitle="The app does not track in the background." />
        <InfoLine icon="phone-portrait-outline" title="Drive Mode runs only while open" subtitle="Keep your phone secured and stop safely before interacting." />
        <InfoLine icon="image-outline" title="Review photos before uploading" subtitle="The connected service blurs detected faces and plates; check the image because detection can miss details." />
      </Panel>

      <Panel style={styles.accountPanel}>
        <AppText size={14} weight="semibold">Account</AppText>
        <InfoLine icon="person-circle-outline" title={user?.displayName || user?.email || (guestMode ? 'Guest session' : 'Not signed in')} subtitle={user ? 'Signed in with Firebase' : 'Local reports stay on this device'} />
        {user || guestMode ? (
          <AppButton title="Sign out" icon="log-out-outline" variant="secondary" onPress={logOut} />
        ) : (
          <AppButton title="Log in" icon="log-in-outline" onPress={() => router.push('/(auth)/login')} />
        )}
      </Panel>
      <AppText size={10} tone="muted" style={styles.version}>PotHoleRadar · Community road watch</AppText>
    </AppScreen>
  );
}

function Preference({
  icon,
  title,
  subtitle,
  value,
  onChange,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle: string;
  value: boolean;
  onChange: (value: boolean) => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.preference}>
      <Ionicons name={icon} size={19} color={colors.accent} />
      <View style={styles.preferenceText}>
        <AppText size={13} weight="medium">{title}</AppText>
        <AppText size={11} tone="muted" style={styles.preferenceSub}>{subtitle}</AppText>
      </View>
      <Switch
        accessibilityLabel={title}
        value={value}
        onValueChange={onChange}
        trackColor={{ false: colors.secondary, true: colors.primary }}
        thumbColor={colors.foreground}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 13, paddingBottom: 40, gap: 17 },
  top: { flexDirection: 'row' },
  panel: { gap: 13 },
  preferences: { gap: 4 },
  accountPanel: { gap: 10 },
  sensitivityRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 },
  adjust: { width: 42, height: 42, borderWidth: 1, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  sensitivityValue: { alignItems: 'center', gap: 2 },
  preference: { minHeight: 66, flexDirection: 'row', alignItems: 'center', gap: 11 },
  preferenceText: { flex: 1, gap: 4 },
  preferenceSub: { lineHeight: 16 },
  version: { textAlign: 'center' },
});
