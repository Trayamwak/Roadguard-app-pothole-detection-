import React from 'react';
import { Image, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';
import type { PotholeDetection, Severity } from '@/types';

function severityColor(severity: Severity, colors: ReturnType<typeof useColors>) {
  return {
    Low: colors.warning,
    Medium: '#FF8A3D',
    High: colors.primary,
    Critical: colors.foreground,
  }[severity];
}

export function DetectionOverlay({ potholes }: { potholes: PotholeDetection[] }) {
  const colors = useColors();
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      {potholes.map((pothole, index) => {
        const [x, y, width, height] = pothole.bbox;
        const color = severityColor(pothole.severity, colors);
        return (
          <View
            key={`${index}-${pothole.severity}`}
            style={[
              styles.box,
              {
                left: `${x * 100}%`,
                top: `${y * 100}%`,
                width: `${width * 100}%`,
                height: `${height * 100}%`,
                borderColor: color,
              },
            ]}
          >
            <View style={[styles.label, { backgroundColor: color }]}>
              <AppText size={9} weight="bold" style={styles.labelText}>
                {pothole.severity} · {pothole.confidence}%
              </AppText>
            </View>
          </View>
        );
      })}
    </View>
  );
}

export function DetectionPreview({
  uri,
  potholes,
}: {
  uri: string;
  potholes: PotholeDetection[];
}) {
  return (
    <View style={styles.imageFrame}>
      <Image source={{ uri }} style={StyleSheet.absoluteFill} resizeMode="stretch" />
      <DetectionOverlay potholes={potholes} />
    </View>
  );
}

const styles = StyleSheet.create({
  imageFrame: { width: '100%', height: 280, borderRadius: 18, overflow: 'hidden', backgroundColor: '#151515' },
  box: { position: 'absolute', borderWidth: 2, borderRadius: 4 },
  label: { position: 'absolute', top: -20, left: -2, paddingHorizontal: 5, paddingVertical: 2, borderRadius: 5 },
  labelText: { color: '#FFFFFF' },
});
