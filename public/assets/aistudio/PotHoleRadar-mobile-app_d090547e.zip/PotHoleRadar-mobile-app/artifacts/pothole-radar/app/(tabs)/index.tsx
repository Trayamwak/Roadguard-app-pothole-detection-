import React, { useCallback, useState } from 'react';
import { Alert, Platform, Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import * as Location from 'expo-location';
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import { AppButton, AppScreen, AppText, Panel, PageTitle, ReportRow, StatTile } from '@/components/AppUI';
import { useApp } from '@/providers/AppProvider';
import { usePotholeDetection } from '@/hooks/usePotholeDetection';
import { usePotholeProximity } from '@/hooks/usePotholeProximity';
import { useColors } from '@/hooks/useColors';
import type { PotholeReport } from '@/types';

function RadarButton({ onPress, enabled }: { onPress: () => void; enabled: boolean }) {
  const colors = useColors();
  const pulse = useSharedValue(1);
  React.useEffect(() => {
    pulse.value = withRepeat(withTiming(1.12, { duration: 1000 }), -1, true);
  }, [pulse]);
  const pulseStyle = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }] }));
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={enabled ? 'Stop Drive Mode' : 'Start Drive Mode'}
      onPress={onPress}
      style={styles.driveButton}
    >
      <Animated.View style={[styles.radarOuter, { borderColor: enabled ? colors.primary : colors.border }, enabled && pulseStyle]}>
        <View style={[styles.radarInner, { backgroundColor: enabled ? '#311412' : colors.secondary }]}>
          <Ionicons name={enabled ? 'pause' : 'radio-outline'} size={29} color={enabled ? colors.primary : colors.accent} />
        </View>
      </Animated.View>
    </Pressable>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const {
    user,
    guestMode,
    reports,
    settings,
    updateSettings,
    firebaseReady,
    addReport,
  } = useApp();
  const [pendingSpike, setPendingSpike] = useState<number | null>(null);
  const [driveError, setDriveError] = useState('');
  const [dismissedProximityId, setDismissedProximityId] = useState<string | null>(null);
  const onPossiblePothole = useCallback((magnitude: number) => {
    setPendingSpike(magnitude);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(() => undefined);
  }, []);
  const { speedKmh, sensorAvailable } = usePotholeDetection(
    settings.driveMode,
    settings.sensitivity,
    onPossiblePothole,
  );
  const proximityAlert = usePotholeProximity(reports, settings.driveMode);

  const startDriveMode = async () => {
    if (settings.driveMode) {
      await updateSettings({ ...settings, driveMode: false });
      return;
    }
    if (Platform.OS === 'web') {
      setDriveError('Drive Mode motion detection is available in the Android and iOS app.');
      return;
    }
    const permission = await Location.getForegroundPermissionsAsync();
    if (!permission.granted) {
      Alert.alert(
        'Location while driving',
        'PotHoleRadar checks your speed and saves a location only when you confirm a report. Location is not tracked in the background.',
        [
          { text: 'Not now', style: 'cancel' },
          {
            text: 'Allow location',
            onPress: async () => {
              const result = await Location.requestForegroundPermissionsAsync();
              if (result.granted) {
                await updateSettings({ ...settings, driveMode: true });
              } else {
                setDriveError('Location is needed to confirm speed and place a report on the map.');
              }
            },
          },
        ],
      );
      return;
    }
    await updateSettings({ ...settings, driveMode: true });
    setDriveError('');
  };

  const confirmSpike = async () => {
    if (pendingSpike == null) return;
    const spike = pendingSpike;
    setPendingSpike(null);
    router.push({
      pathname: '/report/new',
      params: { source: 'sensor', spikeMagnitude: String(spike) },
    });
  };

  const ownReports = reports.filter((report) => report.userId === user?.uid);
  const openReports = reports.filter((report) => report.status === 'open');
  const myPoints = ownReports.length * 25;
  const latest = reports.slice(0, 3);
  const displaySpeed = settings.useMiles ? speedKmh * 0.621371 : speedKmh;
  const speedUnit = settings.useMiles ? 'mph' : 'km/h';
  const greeting = user?.displayName?.trim() || 'Rider';
  const visibleProximityAlert = proximityAlert?.report.id === dismissedProximityId ? null : proximityAlert;
  const proximityDistance = visibleProximityAlert
    ? settings.useMiles
      ? `${(visibleProximityAlert.distance / 1609.34).toFixed(2)} mi`
      : `${Math.round(visibleProximityAlert.distance)} m`
    : '';

  return (
    <AppScreen scroll contentStyle={styles.content}>
      <PageTitle
        eyebrow="PotHoleRadar"
        title={`Good Day, ${greeting}`}
        subtitle={guestMode ? 'Ready to spot some potholes? · Guest mode' : 'Ready to spot some potholes?'}
        right={
          <Pressable accessibilityRole="button" accessibilityLabel="Open your profile" onPress={() => router.push('/(tabs)/profile')} style={styles.profileAvatar}>
            <Ionicons name="person" size={18} color={colors.accent} />
          </Pressable>
        }
      />

      {!firebaseReady ? (
        <Panel style={styles.setupNotice}>
          <View style={styles.noticeIcon}><Ionicons name="cloud-offline-outline" size={19} color={colors.warning} /></View>
          <View style={styles.noticeCopy}>
            <AppText size={13} weight="semibold">Offline-first mode</AppText>
            <AppText size={11} tone="muted" style={styles.noticeText}>
              Reports save on this phone. Connect Firebase to share them with the community.
            </AppText>
          </View>
          <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
        </Panel>
      ) : null}

      <Panel style={styles.drivePanel}>
        <View style={styles.driveTop}>
          <View style={styles.driveCopy}>
            <AppText size={12} tone="accent" weight="bold" style={styles.eyebrow}>ON-ROAD SCAN</AppText>
            <AppText size={20} weight="bold">Drive Mode</AppText>
            <AppText size={12} tone="muted" style={styles.driveText}>
              {settings.driveMode
                ? sensorAvailable
                  ? 'Motion and speed checks are active while this app is open.'
                  : 'Waiting for motion sensor and speed permission.'
                : 'Detect a sharp road impact while moving over 10 km/h.'}
            </AppText>
          </View>
          <RadarButton onPress={startDriveMode} enabled={settings.driveMode} />
        </View>
        <View style={[styles.driveDivider, { backgroundColor: colors.border }]} />
        <View style={styles.driveMetrics}>
          <View style={styles.metricBlock}>
            <AppText size={23} weight="bold">{settings.driveMode ? displaySpeed.toFixed(0) : '—'}</AppText>
            <AppText size={10} tone="muted" weight="medium">{speedUnit.toUpperCase()}</AppText>
          </View>
          <View style={styles.metricBlock}>
            <AppText size={23} weight="bold">{settings.sensitivity.toFixed(1)} g</AppText>
            <AppText size={10} tone="muted" weight="medium">SENSITIVITY</AppText>
          </View>
          <View style={[styles.monitorBadge, { borderColor: settings.driveMode ? '#60302A' : colors.border }]}>
            <View style={[styles.liveDot, { backgroundColor: settings.driveMode ? colors.success : colors.mutedForeground }]} />
            <AppText size={10} weight="semibold" tone={settings.driveMode ? 'success' : 'muted'}>
              {settings.driveMode ? 'ACTIVE' : 'PAUSED'}
            </AppText>
          </View>
        </View>
      </Panel>

      {pendingSpike != null ? (
        <Panel style={[styles.alertPanel, { borderColor: colors.accent }]}>
          <View style={styles.alertHead}>
            <View style={styles.alertIcon}><Ionicons name="alert-circle" size={21} color={colors.accent} /></View>
            <View style={styles.noticeCopy}>
              <AppText size={14} weight="semibold">Possible pothole detected. Confirm?</AppText>
              <AppText size={12} tone="muted">Motion spike: {pendingSpike.toFixed(1)} g</AppText>
            </View>
          </View>
          <View style={styles.alertActions}>
            <AppButton title="Dismiss" variant="secondary" onPress={() => setPendingSpike(null)} style={styles.halfButton} />
            <AppButton title="Confirm" icon="checkmark" onPress={confirmSpike} style={styles.halfButton} />
          </View>
        </Panel>
      ) : null}
      {visibleProximityAlert ? (
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push({ pathname: '/report/[id]', params: { id: visibleProximityAlert.report.id } })}
          style={[styles.proximityAlert, { borderColor: colors.primary }]}
        >
          <View style={styles.proximityIcon}><Ionicons name="warning" size={20} color={colors.primary} /></View>
          <View style={styles.noticeCopy}>
            <AppText size={14} weight="bold" tone="warning">Pothole ahead</AppText>
            <AppText size={11} tone="muted">{visibleProximityAlert.report.severity} · {proximityDistance} away. Drive carefully.</AppText>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Dismiss pothole proximity alert"
            onPress={() => setDismissedProximityId(visibleProximityAlert.report.id)}
            style={styles.dismissAlert}
          >
            <Ionicons name="close" size={17} color={colors.mutedForeground} />
          </Pressable>
        </Pressable>
      ) : null}
      {driveError ? <AppText size={12} tone="warning">{driveError}</AppText> : null}

      <View style={styles.statRow}>
        <StatTile label="Open nearby" value={openReports.length} icon="alert-circle-outline" accent />
        <StatTile label="Your reports" value={ownReports.length} icon="pin-outline" />
        <StatTile label="Radar points" value={myPoints} icon="trophy-outline" />
      </View>

      <View style={styles.sectionHeading}>
        <View>
          <AppText size={18} weight="bold">Quick actions</AppText>
          <AppText size={12} tone="muted" style={styles.sectionSub}>A safer street starts with one report.</AppText>
        </View>
      </View>
      <View style={styles.quickActions}>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push({ pathname: '/report/new', params: { source: 'camera' } })}
          style={({ pressed }) => [styles.actionTile, { backgroundColor: colors.card, borderColor: colors.border }, pressed && styles.pressed]}
        >
          <LinearGradient colors={[colors.primary, colors.accent]} style={styles.actionIcon}>
            <Ionicons name="camera" size={21} color={colors.primaryForeground} />
          </LinearGradient>
          <AppText size={13} weight="semibold">Scan & report</AppText>
          <AppText size={11} tone="muted">Add a photo</AppText>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push('/(tabs)/map')}
          style={({ pressed }) => [styles.actionTile, { backgroundColor: colors.card, borderColor: colors.border }, pressed && styles.pressed]}
        >
          <View style={[styles.actionIcon, { backgroundColor: '#2C2011' }]}>
            <Ionicons name="map" size={21} color={colors.accent} />
          </View>
          <AppText size={13} weight="semibold">Open map</AppText>
          <AppText size={11} tone="muted">See road reports</AppText>
        </Pressable>
      </View>
      <AppButton
        title="AI pothole scan"
        icon="scan-outline"
        variant="secondary"
        onPress={() => router.push('/ai-scan')}
      />
      <Pressable accessibilityRole="button" onPress={() => router.push('/scan-history')} style={styles.historyLink}>
        <Ionicons name="time-outline" size={16} color={colors.accent} />
        <AppText size={12} tone="accent" weight="semibold">View scan history</AppText>
      </Pressable>

      <View style={styles.sectionHeading}>
        <View style={styles.flex}>
          <AppText size={18} weight="bold">Latest sightings</AppText>
          <AppText size={12} tone="muted" style={styles.sectionSub}>Reports from your community</AppText>
        </View>
        <Pressable accessibilityRole="button" onPress={() => router.push('/(tabs)/feed')}>
          <AppText size={12} tone="accent" weight="semibold">View all</AppText>
        </Pressable>
      </View>
      {latest.length ? (
        <View style={styles.latestList}>
          {latest.map((report) => (
            <ReportRow
              key={report.id}
              report={report}
              onPress={() => router.push({ pathname: '/report/[id]', params: { id: report.id } })}
            />
          ))}
        </View>
      ) : (
        <Panel style={styles.firstReport}>
          <View style={styles.firstIcon}><Ionicons name="radio-outline" size={22} color={colors.accent} /></View>
          <View style={styles.noticeCopy}>
            <AppText size={14} weight="semibold">Your radar starts here</AppText>
            <AppText size={12} tone="muted" style={styles.sectionSub}>No reports yet. Spot a pothole? Add a photo and location.</AppText>
          </View>
        </Panel>
      )}

      <Panel style={styles.safety}>
        <Ionicons name="shield-checkmark-outline" size={18} color={colors.success} />
        <AppText size={11} tone="muted" style={styles.safetyText}>
          Please stop in a safe place before taking photos or confirming a road hazard.
        </AppText>
      </Panel>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 14, paddingBottom: 26, gap: 17 },
  eyebrow: { letterSpacing: 1.7 },
  profileAvatar: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: '#2A1A13', borderWidth: 1, borderColor: '#4B211C' },
  setupNotice: { flexDirection: 'row', alignItems: 'center', padding: 12, gap: 11 },
  noticeIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center', backgroundColor: '#322813' },
  noticeCopy: { flex: 1, gap: 4 },
  noticeText: { lineHeight: 16 },
  drivePanel: { padding: 17, gap: 15 },
  driveTop: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  driveCopy: { flex: 1, gap: 5 },
  driveText: { lineHeight: 17, maxWidth: 220 },
  driveButton: { width: 88, height: 88, alignItems: 'center', justifyContent: 'center' },
  radarOuter: { width: 78, height: 78, borderWidth: 1, borderRadius: 39, alignItems: 'center', justifyContent: 'center' },
  radarInner: { width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center' },
  driveDivider: { height: StyleSheet.hairlineWidth },
  driveMetrics: { flexDirection: 'row', alignItems: 'center', gap: 20 },
  metricBlock: { gap: 2 },
  monitorBadge: { marginLeft: 'auto', paddingHorizontal: 9, paddingVertical: 7, borderRadius: 100, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 6 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  alertPanel: { borderWidth: 1, gap: 13 },
  proximityAlert: { borderWidth: 1, borderRadius: 17, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#291311' },
  proximityIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#3A1713' },
  dismissAlert: { width: 30, height: 30, alignItems: 'center', justifyContent: 'center' },
  alertHead: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  alertIcon: { width: 38, height: 38, alignItems: 'center', justifyContent: 'center', borderRadius: 12, backgroundColor: '#31200F' },
  alertActions: { flexDirection: 'row', gap: 9 },
  halfButton: { flex: 1 },
  statRow: { flexDirection: 'row', gap: 9 },
  sectionHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionSub: { marginTop: 4, lineHeight: 17 },
  quickActions: { flexDirection: 'row', gap: 12 },
  historyLink: { alignSelf: 'center', minHeight: 34, flexDirection: 'row', alignItems: 'center', gap: 6 },
  actionTile: { flex: 1, minHeight: 125, borderRadius: 19, borderWidth: 1, padding: 14, gap: 6 },
  actionIcon: { width: 39, height: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  latestList: { gap: 9 },
  firstReport: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  firstIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: '#2C2011', alignItems: 'center', justifyContent: 'center' },
  safety: { flexDirection: 'row', alignItems: 'center', gap: 9, padding: 12 },
  safetyText: { flex: 1, lineHeight: 17 },
  flex: { flex: 1 },
  pressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
});
