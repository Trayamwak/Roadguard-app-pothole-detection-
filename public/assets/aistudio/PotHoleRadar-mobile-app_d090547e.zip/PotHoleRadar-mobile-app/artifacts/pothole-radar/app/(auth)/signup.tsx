import React, { useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { AppButton, AppText, Field, Panel, SmallIconButton } from '@/components/AppUI';
import { auth, firebaseConfigured, getFirebaseSetupMessage } from '@/lib/firebase';
import { useApp } from '@/providers/AppProvider';
import { useColors } from '@/hooks/useColors';

export default function SignupScreen() {
  const colors = useColors();
  const { setGuestMode } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    setError('');
    if (!firebaseConfigured || !auth) {
      setError(getFirebaseSetupMessage());
      return;
    }
    if (!name.trim() || !email.trim() || password.length < 8) {
      setError('Add your name, a valid email, and a password with at least 8 characters.');
      return;
    }
    setBusy(true);
    try {
      const credential = await createUserWithEmailAndPassword(auth, email.trim(), password);
      await updateProfile(credential.user, { displayName: name.trim() });
      setGuestMode(false);
      router.replace('/(tabs)');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not create your account.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={styles.content}
      bottomOffset={70}
      keyboardShouldPersistTaps="handled"
    >
      <SmallIconButton icon="arrow-back" accessibilityLabel="Back" onPress={() => router.back()} />
      <View style={styles.header}>
        <View style={[styles.mark, { backgroundColor: '#291311' }]}>
          <AppText size={24} tone="accent" weight="bold">P</AppText>
        </View>
        <AppText size={30} weight="bold">Join the road watch</AppText>
        <AppText size={14} tone="muted">Make safer streets a shared effort.</AppText>
      </View>
      <Panel style={styles.form}>
        <Field label="Your name" value={name} onChangeText={setName} placeholder="How should we call you?" autoCapitalize="words" autoComplete="name" />
        <Field label="Email address" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" autoComplete="email" />
        <Field label="Password" value={password} onChangeText={setPassword} placeholder="At least 8 characters" secureTextEntry autoComplete="new-password" />
        <AppText size={11} tone="muted" style={styles.privacy}>Your account identifies report ownership. You can still display individual reports anonymously.</AppText>
        {error ? <AppText size={12} tone="primary" style={styles.error}>{error}</AppText> : null}
        <AppButton title="Create account" icon="arrow-forward" loading={busy} onPress={submit} testID="signup-submit" />
      </Panel>
      <View style={styles.footer}>
        <AppText size={13} tone="muted">Already have an account?</AppText>
        <Pressable accessibilityRole="button" onPress={() => router.replace('/(auth)/login')}>
          <AppText size={13} tone="accent" weight="semibold"> Log in</AppText>
        </Pressable>
      </View>
      {!firebaseConfigured ? (
        <Panel style={{ borderColor: colors.border }}>
          <AppText size={12} tone="muted" style={{ lineHeight: 18 }}>{getFirebaseSetupMessage()}</AppText>
        </Panel>
      ) : null}
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 22, paddingTop: 20, paddingBottom: 40, gap: 22, maxWidth: 520, width: '100%', alignSelf: 'center' },
  header: { gap: 8, marginTop: 4 },
  mark: { width: 52, height: 52, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  form: { gap: 17 },
  privacy: { lineHeight: 17 },
  error: { lineHeight: 18 },
  footer: { flexDirection: 'row', justifyContent: 'center', gap: 2 },
});
